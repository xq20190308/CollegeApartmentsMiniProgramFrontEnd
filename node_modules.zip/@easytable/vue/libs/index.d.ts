import type { Plugin } from 'vue';
import VeCheckbox from './packages/ve-checkbox';
import VeCheckboxGroup from './packages/ve-checkbox-group';
import VeContextmenu from './packages/ve-contextmenu';
import VeDropdown from './packages/ve-dropdown';
import VeIcon from './packages/ve-icon';
import VeLoading from './packages/ve-loading';
import VeLocale from './packages/ve-locale';
import VePagination from './packages/ve-pagination';
import VeRadio from './packages/ve-radio';
import VeSelect from './packages/ve-select';
import VeTable from './packages/ve-table/src';
import type { LocaleMessage } from './packages/common/locale';
declare const version = "0.0.6";
declare const useVeTable: (options?: {
    locale?: LocaleMessage | undefined;
} | undefined) => Plugin;
export { useVeTable, version, VeCheckbox, VeCheckboxGroup, VeContextmenu, VeDropdown, VeIcon, VeLoading, VeLocale, VePagination, VeRadio, VeSelect, VeTable, };
