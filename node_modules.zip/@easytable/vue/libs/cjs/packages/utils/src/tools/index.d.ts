export declare const isStr: (str: any) => str is string;
export declare const isNum: (num: any) => num is number;
