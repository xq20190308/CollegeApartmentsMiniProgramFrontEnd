import type { Ref } from 'vue';
import { Plugin } from 'vue';
import type { LocaleMessage } from '../common/locale';
declare const _default: {
    getMessage(): LocaleMessage;
    use(lang: LocaleMessage): void;
    update(lang?: {}): void;
} & Plugin<any[]>;
export default _default;
export declare function provideLocale(lang: Ref<LocaleMessage | undefined>): void;
export declare function useLocale(): {
    getMessage(): LocaleMessage | undefined;
    update(newLang?: {}): void;
};
