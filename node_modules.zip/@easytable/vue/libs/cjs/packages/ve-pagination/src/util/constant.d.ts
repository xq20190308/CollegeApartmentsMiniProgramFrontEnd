export declare const PREFIX_CLS = "ve-pagination-";
export declare const LOCALE_COMP_NAME = "pagination";
export declare const EMIT_EVENTS: {
    PAGE_NUMBER_CHANGE: string;
    PAGE_SIZE_CHANGE: string;
};
export declare const COMPS_NAME: {
    VE_PAGINATION: string;
};
