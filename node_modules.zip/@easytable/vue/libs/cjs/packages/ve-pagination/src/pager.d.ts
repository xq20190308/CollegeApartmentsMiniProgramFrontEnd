declare const _default: import("vue").DefineComponent<{
    pageCount: {
        type: NumberConstructor;
        required: true;
    };
    pageIndex: {
        type: NumberConstructor;
        required: true;
    };
    pagingCount: {
        type: NumberConstructor;
        required: true;
    };
}, unknown, unknown, {
    numOffset(): number;
    showJumpPrev(): boolean;
    showJumpNext(): boolean;
    pagingCounts(): number[];
}, {
    jumpPage(pageIndex: number): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    pageCount: {
        type: NumberConstructor;
        required: true;
    };
    pageIndex: {
        type: NumberConstructor;
        required: true;
    };
    pagingCount: {
        type: NumberConstructor;
        required: true;
    };
}>>, {}, {}>;
export default _default;
