import VeLoading from './src/index';
declare const _default: typeof VeLoading & import("vue").Plugin<any[]>;
export default _default;
