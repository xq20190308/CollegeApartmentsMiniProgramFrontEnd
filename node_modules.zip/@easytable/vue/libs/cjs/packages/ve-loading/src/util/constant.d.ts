export declare const PREFIX_CLS = "ve-loading-";
export declare const EMIT_EVENTS: {};
export declare const COMPS_NAME: {
    VE_LOADING: string;
    VE_LOADING_PLANE: string;
    VE_LOADING_BOUNCE: string;
    VE_LOADING_WAVE: string;
    VE_LOADING_PULSE: string;
    VE_LOADING_FLOW: string;
    VE_LOADING_GRID: string;
    VE_LOADING_FOLD: string;
};
export declare const SPIN_NAMES: {
    PLANE: string;
    GRID: string;
    WAVE: string;
    FLOW: string;
    BOUNCE: string;
    PULSE: string;
};
