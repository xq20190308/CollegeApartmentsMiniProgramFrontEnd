declare const _default: import("vue").DefineComponent<{
    color: {
        type: StringConstructor;
        required: true;
    };
    width: {
        type: (StringConstructor | NumberConstructor)[];
        required: true;
    };
    height: {
        type: (StringConstructor | NumberConstructor)[];
        required: true;
    };
}, unknown, unknown, {
    spinStyle(): {
        width: string;
        height: string;
    };
    itemStyle(): {
        'background-color': string;
    };
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    color: {
        type: StringConstructor;
        required: true;
    };
    width: {
        type: (StringConstructor | NumberConstructor)[];
        required: true;
    };
    height: {
        type: (StringConstructor | NumberConstructor)[];
        required: true;
    };
}>>, {}, {}>;
export default _default;
