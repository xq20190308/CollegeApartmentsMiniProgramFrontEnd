import VeLoading from './loading';
declare type VeLoadingProps = NonNullable<Partial<(typeof VeLoading)['__defaults']>>;
declare function Loading(options?: VeLoadingProps): {
    instance: import("vue").CreateComponentPublicInstance<Readonly<globalThis.ExtractPropTypes<{
        name: {
            type: globalThis.PropType<"flow" | "grid" | "plane" | "wave" | "bounce" | "pulse">;
            default: string;
        };
        visible: {
            type: BooleanConstructor;
            default: boolean;
        };
        color: {
            type: StringConstructor;
            default: string;
        };
        overlayBackgroundColor: {
            type: StringConstructor;
            default: string;
        };
        width: {
            type: NumberConstructor;
            default: number;
        };
        height: {
            type: NumberConstructor;
            default: number;
        };
        tip: {
            type: StringConstructor;
            default: string;
        };
        fullscreen: {
            type: BooleanConstructor;
            default: boolean;
        };
        target: {
            type: globalThis.PropType<string | HTMLElement>;
            default: string;
        };
        lock: {
            type: BooleanConstructor;
            default: boolean;
        };
        parent__: {
            type: globalThis.PropType<HTMLElement | null>;
            default: null;
        };
    }>>, unknown, {
        _visible: boolean;
    }, {
        loadingClass(): {
            [x: string]: boolean;
        };
        loadingStyle(): {
            'background-color': string;
        };
    }, {
        setVisible(v: boolean): void;
    }, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<globalThis.ExtractPropTypes<{
        name: {
            type: globalThis.PropType<"flow" | "grid" | "plane" | "wave" | "bounce" | "pulse">;
            default: string;
        };
        visible: {
            type: BooleanConstructor;
            default: boolean;
        };
        color: {
            type: StringConstructor;
            default: string;
        };
        overlayBackgroundColor: {
            type: StringConstructor;
            default: string;
        };
        width: {
            type: NumberConstructor;
            default: number;
        };
        height: {
            type: NumberConstructor;
            default: number;
        };
        tip: {
            type: StringConstructor;
            default: string;
        };
        fullscreen: {
            type: BooleanConstructor;
            default: boolean;
        };
        target: {
            type: globalThis.PropType<string | HTMLElement>;
            default: string;
        };
        lock: {
            type: BooleanConstructor;
            default: boolean;
        };
        parent__: {
            type: globalThis.PropType<HTMLElement | null>;
            default: null;
        };
    }>>, {
        name: "flow" | "grid" | "plane" | "wave" | "bounce" | "pulse";
        color: string;
        width: number;
        height: number;
        fullscreen: boolean;
        target: string | HTMLElement;
        visible: boolean;
        overlayBackgroundColor: string;
        tip: string;
        lock: boolean;
        parent__: HTMLElement | null;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<globalThis.ExtractPropTypes<{
        name: {
            type: globalThis.PropType<"flow" | "grid" | "plane" | "wave" | "bounce" | "pulse">;
            default: string;
        };
        visible: {
            type: BooleanConstructor;
            default: boolean;
        };
        color: {
            type: StringConstructor;
            default: string;
        };
        overlayBackgroundColor: {
            type: StringConstructor;
            default: string;
        };
        width: {
            type: NumberConstructor;
            default: number;
        };
        height: {
            type: NumberConstructor;
            default: number;
        };
        tip: {
            type: StringConstructor;
            default: string;
        };
        fullscreen: {
            type: BooleanConstructor;
            default: boolean;
        };
        target: {
            type: globalThis.PropType<string | HTMLElement>;
            default: string;
        };
        lock: {
            type: BooleanConstructor;
            default: boolean;
        };
        parent__: {
            type: globalThis.PropType<HTMLElement | null>;
            default: null;
        };
    }>>, {}, {
        _visible: boolean;
    }, {
        loadingClass(): {
            [x: string]: boolean;
        };
        loadingStyle(): {
            'background-color': string;
        };
    }, {
        setVisible(v: boolean): void;
    }, {
        name: "flow" | "grid" | "plane" | "wave" | "bounce" | "pulse";
        color: string;
        width: number;
        height: number;
        fullscreen: boolean;
        target: string | HTMLElement;
        visible: boolean;
        overlayBackgroundColor: string;
        tip: string;
        lock: boolean;
        parent__: HTMLElement | null;
    }>;
    show: () => void;
    close: () => void;
    destroy: () => void;
};
export default Loading;
