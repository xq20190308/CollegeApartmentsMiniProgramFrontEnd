declare const _default: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<globalThis.ExtractPropTypes<{
        modelValue: {
            type: (BooleanConstructor | StringConstructor | NumberConstructor)[];
            default: null;
        };
        label: {
            type: StringConstructor;
            default: null;
        };
        disabled: BooleanConstructor;
        isControlled: {
            type: BooleanConstructor;
            default: boolean;
        };
        isSelected: {
            type: BooleanConstructor;
            default: boolean;
        };
    }>>, unknown, {
        model: string | number | boolean;
    }, {
        radioClass(): (string | {
            [x: string]: string | number | boolean;
        })[];
        internalIsSelected(): string | number | boolean;
    }, {
        checkedChange(event: Event): false | undefined;
        getLabelContent(): string | globalThis.VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[] | undefined;
        initModel(): void;
        updateModelBySingle(): void;
    }, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<globalThis.ExtractPropTypes<{
        modelValue: {
            type: (BooleanConstructor | StringConstructor | NumberConstructor)[];
            default: null;
        };
        label: {
            type: StringConstructor;
            default: null;
        };
        disabled: BooleanConstructor;
        isControlled: {
            type: BooleanConstructor;
            default: boolean;
        };
        isSelected: {
            type: BooleanConstructor;
            default: boolean;
        };
    }>>, {
        modelValue: string | number | boolean;
        label: string;
        disabled: boolean;
        isControlled: boolean;
        isSelected: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<globalThis.ExtractPropTypes<{
        modelValue: {
            type: (BooleanConstructor | StringConstructor | NumberConstructor)[];
            default: null;
        };
        label: {
            type: StringConstructor;
            default: null;
        };
        disabled: BooleanConstructor;
        isControlled: {
            type: BooleanConstructor;
            default: boolean;
        };
        isSelected: {
            type: BooleanConstructor;
            default: boolean;
        };
    }>>, {}, {
        model: string | number | boolean;
    }, {
        radioClass(): (string | {
            [x: string]: string | number | boolean;
        })[];
        internalIsSelected(): string | number | boolean;
    }, {
        checkedChange(event: Event): false | undefined;
        getLabelContent(): string | globalThis.VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[] | undefined;
        initModel(): void;
        updateModelBySingle(): void;
    }, {
        modelValue: string | number | boolean;
        label: string;
        disabled: boolean;
        isControlled: boolean;
        isSelected: boolean;
    }>;
    __isFragment?: undefined;
    __isTeleport?: undefined;
    __isSuspense?: undefined;
} & import("vue").ComponentOptionsBase<Readonly<globalThis.ExtractPropTypes<{
    modelValue: {
        type: (BooleanConstructor | StringConstructor | NumberConstructor)[];
        default: null;
    };
    label: {
        type: StringConstructor;
        default: null;
    };
    disabled: BooleanConstructor;
    isControlled: {
        type: BooleanConstructor;
        default: boolean;
    };
    isSelected: {
        type: BooleanConstructor;
        default: boolean;
    };
}>>, unknown, {
    model: string | number | boolean;
}, {
    radioClass(): (string | {
        [x: string]: string | number | boolean;
    })[];
    internalIsSelected(): string | number | boolean;
}, {
    checkedChange(event: Event): false | undefined;
    getLabelContent(): string | globalThis.VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[] | undefined;
    initModel(): void;
    updateModelBySingle(): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    modelValue: string | number | boolean;
    label: string;
    disabled: boolean;
    isControlled: boolean;
    isSelected: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin<any[]>;
export default _default;
