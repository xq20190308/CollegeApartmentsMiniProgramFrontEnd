export declare const PREFIX_CLS = "ve-radio-";
export declare const EMIT_EVENTS: {
    ON_RADIO_CHANGE: string;
};
export declare const COMPS_NAME: {
    VE_RADIO: string;
};
