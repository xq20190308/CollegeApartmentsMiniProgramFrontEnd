declare const _default: import("vue").DefineComponent<{
    modelValue: {
        type: (BooleanConstructor | StringConstructor | NumberConstructor)[];
        default: null;
    };
    label: {
        type: StringConstructor;
        default: null;
    };
    disabled: BooleanConstructor;
    isControlled: {
        type: BooleanConstructor;
        default: boolean;
    };
    isSelected: {
        type: BooleanConstructor;
        default: boolean;
    };
}, unknown, {
    model: string | number | boolean;
}, {
    radioClass(): (string | {
        [x: string]: string | number | boolean;
    })[];
    internalIsSelected(): string | number | boolean;
}, {
    checkedChange(event: Event): false | undefined;
    getLabelContent(): string | globalThis.VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[] | undefined;
    initModel(): void;
    updateModelBySingle(): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    modelValue: {
        type: (BooleanConstructor | StringConstructor | NumberConstructor)[];
        default: null;
    };
    label: {
        type: StringConstructor;
        default: null;
    };
    disabled: BooleanConstructor;
    isControlled: {
        type: BooleanConstructor;
        default: boolean;
    };
    isSelected: {
        type: BooleanConstructor;
        default: boolean;
    };
}>>, {
    modelValue: string | number | boolean;
    label: string;
    disabled: boolean;
    isControlled: boolean;
    isSelected: boolean;
}, {}>;
export default _default;
