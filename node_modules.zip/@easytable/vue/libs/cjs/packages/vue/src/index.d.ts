import type { Plugin } from 'vue';
import VeCheckbox from '../../ve-checkbox';
import VeCheckboxGroup from '../../ve-checkbox-group';
import VeContextmenu from '../../ve-contextmenu';
import VeDropdown from '../../ve-dropdown';
import VeIcon from '../../ve-icon';
import VeLoading from '../../ve-loading';
import VeLocale from '../../ve-locale';
import VePagination from '../../ve-pagination';
import VeRadio from '../../ve-radio';
import VeSelect from '../../ve-select';
import VeTable from '../../ve-table/src';
import type { LocaleMessage } from '../../common/locale';
declare const version = "0.0.6";
declare const useVeTable: (options?: {
    locale?: LocaleMessage | undefined;
} | undefined) => Plugin;
export { useVeTable, version, VeCheckbox, VeCheckboxGroup, VeContextmenu, VeDropdown, VeIcon, VeLoading, VeLocale, VePagination, VeRadio, VeSelect, VeTable, };
