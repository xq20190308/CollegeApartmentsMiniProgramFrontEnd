import type { PropType } from 'vue';
declare const _default: import("vue").DefineComponent<{
    locale: {
        type: PropType<LocaleMessage>;
    };
}, () => globalThis.VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>[] | undefined, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    locale: {
        type: PropType<LocaleMessage>;
    };
}>>, {}, {}>;
export default _default;
