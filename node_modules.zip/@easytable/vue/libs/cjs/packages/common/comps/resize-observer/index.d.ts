import VueDomResizeObserver from './src/index';
export default VueDomResizeObserver;
