declare const _default: import("vue").DefineComponent<{
    tagName: {
        type: StringConstructor;
        required: true;
    };
    id: {
        type: (StringConstructor | NumberConstructor)[];
        default: null;
    };
}, unknown, unknown, {}, {
    resizeListener(contentRect: DOMRect): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    tagName: {
        type: StringConstructor;
        required: true;
    };
    id: {
        type: (StringConstructor | NumberConstructor)[];
        default: null;
    };
}>>, {
    id: string | number;
}, {}>;
export default _default;
