import type { Plugin } from 'vue';
export declare function withUse<T>(Component: T, customInstall?: Plugin['install']): T & Plugin<any[]>;
