import type { LocaleMessage } from '..';
declare const _default: LocaleMessage;
export default _default;
