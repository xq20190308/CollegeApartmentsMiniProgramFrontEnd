export declare type LocaleMessage = Record<string, Record<string, string | ((...args: any[]) => string)>>;
export declare function createI18N(compName: keyof LocaleMessage): (path: string, ...args: any[]) => string;
