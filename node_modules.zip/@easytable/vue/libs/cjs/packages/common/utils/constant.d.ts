export declare const KEY_CODES: {
    BACK_SPACE: number;
    TAB: number;
    ENTER: number;
    SHIFT: number;
    SPACE: number;
    ARROW_LEFT: number;
    ARROW_UP: number;
    ARROW_RIGHT: number;
    ARROW_DOWN: number;
    DELETE: number;
    F2: number;
};
export declare const ICON_NAMES: {
    FILTER: string;
    DOUBLE_RIGHT_ARROW: string;
    DOUBLE_LEFT_ARROW: string;
    TOP_ARROW: string;
    RIGHT_ARROW: string;
    BOTTOM_ARROW: string;
    LEFT_ARROW: string;
    SORT_TOP_ARROW: string;
    SORT_BOTTOM_ARROW: string;
    SEARCH: string;
};
export declare const MOUSE_EVENT_CLICK_TYPE: {
    LEFT_MOUSE: number;
    MIDDLE_MOUSE: number;
    RIGHT_MOUSE: number;
};
