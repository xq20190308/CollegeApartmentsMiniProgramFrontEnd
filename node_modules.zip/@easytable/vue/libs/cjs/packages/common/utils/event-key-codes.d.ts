export declare function isInputKeyCode(event: KeyboardEvent): boolean;
export declare function isDirectionKeyCode(keyCode: number): boolean;
