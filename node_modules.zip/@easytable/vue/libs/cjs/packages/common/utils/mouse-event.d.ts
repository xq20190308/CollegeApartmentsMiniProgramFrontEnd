export declare function getMouseEventClickType(event: MouseEvent): number | null;
