export declare function addClass(el: HTMLElement, cls: string): void;
export declare function removeClass(el: HTMLElement, cls: string): void;
export declare function hasClass(el: HTMLElement, cls: string): boolean;
export declare function getViewportOffset(triggerEl: HTMLElement): {
    offsetTop: number;
    offsetLeft: number;
    left: number;
    top: number;
    right: number;
    bottom: number;
    right2: number;
    bottom2: number;
};
export declare function getViewportOffsetWithinContainer(triggerEl: HTMLElement, containerEl: HTMLElement): {
    offsetTop: number;
    offsetLeft: number;
    left: number;
    top: number;
    right: number;
    bottom: number;
    right2: number;
    bottom2: number;
};
export declare function getMousePosition(event: MouseEvent): {
    left: number;
    top: number;
    right: number;
    bottom: number;
};
/**
 * Returns caret position in text input.
 *
 * @author https://stackoverflow.com/questions/263743/how-to-get-caret-position-in-textarea
 * @param {HTMLElement} el An element to check.
 * @returns {number}
 */
export declare function getCaretPosition(el: HTMLInputElement): any;
/**
 * Sets caret position in text input.
 *
 * @author http://blog.vishalon.net/index.php/javascript-getting-and-setting-caret-position-in-textarea/
 * @param {Element} element An element to process.
 * @param {number} pos The selection start position.
 * @param {number} endPos The selection end position.
 */
export declare function setCaretPosition(element: HTMLInputElement, pos: number, endPos: number): void;
