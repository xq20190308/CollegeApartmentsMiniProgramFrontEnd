export declare const raf: typeof requestAnimationFrame;
export declare const caf: typeof cancelAnimationFrame;
