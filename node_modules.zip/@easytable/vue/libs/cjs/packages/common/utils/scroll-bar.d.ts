export declare function getScrollbarWidth(): number;
