/**
 * Generate a non duplicate ID
 */
export declare function getRandomId(): string;
