export declare const addResizeListener: (element: HTMLElement & Record<string, any>, fn: Function) => void;
export declare const removeResizeListener: (element: HTMLElement & Record<string, any>, fn: Function) => void;
