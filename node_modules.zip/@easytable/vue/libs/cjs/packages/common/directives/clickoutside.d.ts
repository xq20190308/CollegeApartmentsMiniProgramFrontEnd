import type { Directive } from 'vue';
declare const clickoutside: Directive;
export default clickoutside;
