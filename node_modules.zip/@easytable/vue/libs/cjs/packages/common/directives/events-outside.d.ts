import type { Directive } from 'vue';
declare const eventsOutside: Directive;
export default eventsOutside;
