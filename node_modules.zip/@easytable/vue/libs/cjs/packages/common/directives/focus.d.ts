import type { Directive } from 'vue';
declare const focus: Directive;
export default focus;
