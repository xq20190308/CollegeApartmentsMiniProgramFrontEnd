export declare const INSTANCE_METHODS: {
    TEXTAREA_ADD_NEW_LINE: string;
    TEXTAREA_SELECT: string;
};
