declare const _default: import("vue").DefineComponent<{
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
}, unknown, unknown, {
    trClass(): {
        [x: string]: boolean;
    };
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
}>>, {}, {}>;
export default _default;
