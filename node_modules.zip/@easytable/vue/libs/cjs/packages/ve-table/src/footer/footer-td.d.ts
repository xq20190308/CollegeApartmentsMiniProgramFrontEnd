declare const _default: import("vue").DefineComponent<{
    rowData: {
        type: ObjectConstructor;
        required: true;
    };
    column: {
        type: ObjectConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
    cellSpanOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    footerRows: {
        type: ArrayConstructor;
        default(): never[];
    };
    fixedFooter: {
        type: BooleanConstructor;
        default: boolean;
    };
}, unknown, unknown, {
    isLastLeftFixedColumn(): boolean;
    isfirstRightFixedColumn(): boolean;
}, {
    getBodyTdClass({ fixed }: {
        fixed: any;
    }): {
        [x: string]: boolean;
    };
    getBodyTdStyle({ key, align, fixed }: {
        key: any;
        align: any;
        fixed: any;
    }): {};
    getRenderContent(h: any): any;
    getCellSpan(): {
        rowspan: number;
        colspan: number;
    };
    cellClick(e: any, fn: any): void;
    cellDblclick(e: any, fn: any): void;
    cellContextmenu(e: any, fn: any): void;
    cellMouseenter(e: any, fn: any): void;
    cellMouseleave(e: any, fn: any): void;
    cellMousemove(e: any, fn: any): void;
    cellMouseover(e: any, fn: any): void;
    cellMousedown(e: any, fn: any): void;
    cellMouseup(e: any, fn: any): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    rowData: {
        type: ObjectConstructor;
        required: true;
    };
    column: {
        type: ObjectConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
    cellSpanOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    footerRows: {
        type: ArrayConstructor;
        default(): never[];
    };
    fixedFooter: {
        type: BooleanConstructor;
        default: boolean;
    };
}>>, {
    rowKeyFieldName: string;
    cellSelectionData: Record<string, any>;
    cellStyleOption: Record<string, any>;
    eventCustomOption: Record<string, any>;
    cellSpanOption: Record<string, any>;
    footerRows: unknown[];
    fixedFooter: boolean;
}, {}>;
export default _default;
