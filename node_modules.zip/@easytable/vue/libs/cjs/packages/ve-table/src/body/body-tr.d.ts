declare const _default: import("vue").DefineComponent<{
    rowData: {
        type: ObjectConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    columnCollection: {
        type: ArrayConstructor;
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
    allRowKeys: {
        type: ArrayConstructor;
        required: true;
    };
    expandOption: {
        type: ObjectConstructor;
        default(): null;
    };
    isExpandRow: {
        type: BooleanConstructor;
        required: true;
    };
    expandedRowkeys: {
        type: ArrayConstructor;
        default(): never[];
    };
    expandRowChange: {
        type: FunctionConstructor;
        default: null;
    };
    checkboxOption: {
        type: ObjectConstructor;
        default(): null;
    };
    internalCheckboxSelectedRowKeys: {
        type: ArrayConstructor;
        default(): null;
    };
    radioOption: {
        type: ObjectConstructor;
        default(): null;
    };
    internalRadioSelectedRowKey: {
        type: (StringConstructor | NumberConstructor)[];
        default: null;
    };
    isVirtualScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    highlightRowKey: {
        type: (StringConstructor | NumberConstructor)[];
        default: null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionRangeData: {
        type: ObjectConstructor;
        default(): null;
    };
    bodyIndicatorRowKeys: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSpanOption: {
        type: ObjectConstructor;
        default(): null;
    };
    editOption: {
        type: ObjectConstructor;
        default(): null;
    };
}, unknown, unknown, {
    currentRowKey(): any;
    trClass(): {
        [x: string]: boolean;
    };
}, {
    rowClick(e: any, fn: any): void;
    rowDblclick(e: any, fn: any): void;
    rowContextmenu(e: any, fn: any): void;
    rowMouseenter(e: any, fn: any): void;
    rowMouseleave(e: any, fn: any): void;
    rowMousemove(e: any, fn: any): void;
    rowMouseover(e: any, fn: any): void;
    rowMousedown(e: any, fn: any): void;
    rowMouseup(e: any, fn: any): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    rowData: {
        type: ObjectConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    columnCollection: {
        type: ArrayConstructor;
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
    allRowKeys: {
        type: ArrayConstructor;
        required: true;
    };
    expandOption: {
        type: ObjectConstructor;
        default(): null;
    };
    isExpandRow: {
        type: BooleanConstructor;
        required: true;
    };
    expandedRowkeys: {
        type: ArrayConstructor;
        default(): never[];
    };
    expandRowChange: {
        type: FunctionConstructor;
        default: null;
    };
    checkboxOption: {
        type: ObjectConstructor;
        default(): null;
    };
    internalCheckboxSelectedRowKeys: {
        type: ArrayConstructor;
        default(): null;
    };
    radioOption: {
        type: ObjectConstructor;
        default(): null;
    };
    internalRadioSelectedRowKey: {
        type: (StringConstructor | NumberConstructor)[];
        default: null;
    };
    isVirtualScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    highlightRowKey: {
        type: (StringConstructor | NumberConstructor)[];
        default: null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionRangeData: {
        type: ObjectConstructor;
        default(): null;
    };
    bodyIndicatorRowKeys: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSpanOption: {
        type: ObjectConstructor;
        default(): null;
    };
    editOption: {
        type: ObjectConstructor;
        default(): null;
    };
}>>, {
    cellSelectionRangeData: Record<string, any>;
    bodyIndicatorRowKeys: Record<string, any>;
    rowKeyFieldName: string;
    cellSelectionData: Record<string, any>;
    checkboxOption: Record<string, any>;
    cellStyleOption: Record<string, any>;
    eventCustomOption: Record<string, any>;
    expandOption: Record<string, any>;
    expandedRowkeys: unknown[];
    internalRadioSelectedRowKey: string | number;
    radioOption: Record<string, any>;
    internalCheckboxSelectedRowKeys: unknown[];
    cellSpanOption: Record<string, any>;
    editOption: Record<string, any>;
    expandRowChange: Function;
    isVirtualScroll: boolean;
    highlightRowKey: string | number;
}, {}>;
export default _default;
