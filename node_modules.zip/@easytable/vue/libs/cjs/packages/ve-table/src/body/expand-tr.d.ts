declare const _default: import("vue").DefineComponent<{
    tableViewportWidth: {
        type: NumberConstructor;
        default: number;
    };
    expandColumn: {
        type: ObjectConstructor;
        default(): null;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    expandOption: {
        type: ObjectConstructor;
        default(): null;
    };
    expandedRowkeys: {
        type: ArrayConstructor;
        default(): never[];
    };
    rowData: {
        type: ObjectConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
}, unknown, unknown, {
    columnCount(): number;
    currentRowKey(): any;
    isRowExpanded(): boolean;
    expanRowClass(): {
        [x: string]: boolean;
    };
    hasLeftFixedColumn(): boolean;
    expandTdContentStyle(): {};
}, {
    getExpandRowContent(): any;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    tableViewportWidth: {
        type: NumberConstructor;
        default: number;
    };
    expandColumn: {
        type: ObjectConstructor;
        default(): null;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    expandOption: {
        type: ObjectConstructor;
        default(): null;
    };
    expandedRowkeys: {
        type: ArrayConstructor;
        default(): never[];
    };
    rowData: {
        type: ObjectConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
}>>, {
    rowKeyFieldName: string;
    tableViewportWidth: number;
    expandColumn: Record<string, any>;
    expandOption: Record<string, any>;
    expandedRowkeys: unknown[];
}, {}>;
export default _default;
