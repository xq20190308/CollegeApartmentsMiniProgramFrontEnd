declare const _default: import("vue").DefineComponent<Readonly<import("vue").ComponentPropsOptions<{
    [x: string]: unknown;
}>>, unknown, {
    columnResizerStartX: number;
    currentResizingColumn: null;
    columnResizerHandlerWidth: number;
    columnResizerRect: {
        top: number;
        left: number;
        height: number;
    };
}, {
    columnMinWidth(): number;
}, {
    initColumnResizerPosition({ event, column }: {
        event: any;
        column: any;
    }): false | undefined;
    setColumnResizerPositionByDrag(event: any): void;
    columnResizerHandlerMousedown({ event }: {
        event: any;
    }): void;
    columnResizerMouseup(event: any): false | undefined;
    clearColumnResizerStatus(): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, readonly string[] | Readonly<globalThis.ExtractPropTypes<Readonly<import("vue").ComponentObjectPropsOptions<{
    [x: string]: unknown;
}>>>>, {
    [x: number]: string;
} | {}, {}>;
export default _default;
