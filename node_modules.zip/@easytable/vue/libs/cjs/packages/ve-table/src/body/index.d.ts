declare const _default: import("vue").DefineComponent<Readonly<import("vue").ComponentPropsOptions<{
    [x: string]: unknown;
}>>, unknown, {
    colsWidths: Map<any, any>;
    internalExpandRowkeys: never[];
    internalCheckboxSelectedRowKeys: never[];
    internalRadioSelectedRowKey: null;
    virtualScrollPreviewRenderedRowKeys: never[];
    virtualScrollRepeatRenderedRowKeys: never[];
}, {
    columnCollection(): any[];
    expandColumn(): any;
    isControlledExpand(): any;
    expandedRowkeys(): any;
    disableCheckboxSelectedRowKeys(): any[];
    disableCheckboxUnselectedRowKeys(): any[];
    isCheckboxSelectedAll(): boolean;
    isCheckboxIndeterminate(): boolean;
    isControlledRadio(): any;
}, {
    isLastLeftFixedColumn(column: any): boolean;
    isfirstRightFixedColumn(column: any): boolean;
    expandRowChange(rowData: any, rowIndex: any): false | undefined;
    rowClick({ rowData, rowIndex }: {
        rowData: any;
        rowIndex: any;
    }): false | undefined;
    isExpandRow({ rowData, rowIndex }: {
        rowData: any;
        rowIndex: any;
    }): boolean;
    tdSizeChange({ key, width }: {
        key: any;
        width: any;
    }): void;
    initInternalExpandRowKeys(): false | undefined;
    getExpandRowComp({ rowData, rowIndex }: {
        rowData: any;
        rowIndex: any;
    }): JSX.Element | null;
    sendToCheckboxAll(): void;
    initInternalRadioSelectedRowKey(): false | undefined;
    initInternalCheckboxSelectedRowKeys(): false | undefined;
    resetInternalCheckboxSelectedRowKeys(): void;
    checkboxSelectedRowChange({ rowKey, isSelected }: {
        rowKey: any;
        isSelected: any;
    }): void;
    checkboxSelectedAllChange({ isSelected }: {
        isSelected: any;
    }): void;
    radioSelectedRowChange({ rowKey }: {
        rowKey: any;
    }): void;
    getTrKey({ rowData, rowIndex }: {
        rowData: any;
        rowIndex: any;
    }): any;
    renderingRowKeys(rowKeys: any): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, readonly string[] | Readonly<globalThis.ExtractPropTypes<Readonly<import("vue").ComponentObjectPropsOptions<{
    [x: string]: unknown;
}>>>>, {
    [x: number]: string;
} | {}, {}>;
export default _default;
