declare const _default: import("vue").DefineComponent<{
    groupColumn: {
        type: ArrayConstructor;
        required: true;
    };
    groupColumnItem: {
        type: ObjectConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    headerRows: {
        type: ArrayConstructor;
        default(): never[];
    };
    fixedHeader: {
        type: BooleanConstructor;
    };
    isGroupHeader: {
        type: BooleanConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionRangeData: {
        type: ObjectConstructor;
        default(): null;
    };
    headerIndicatorColKeys: {
        type: ObjectConstructor;
        default(): null;
    };
    checkboxOption: {
        type: ObjectConstructor;
        default(): null;
    };
    sortOption: {
        type: ObjectConstructor;
        default(): null;
    };
    sortColumns: {
        type: ObjectConstructor;
        default(): null;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
}, unknown, unknown, {
    isLastLeftFixedColumn(): boolean;
    isfirstRightFixedColumn(): boolean;
    isLastCloumn(): boolean;
    isSortableCloumn(): boolean;
}, {
    getTheadThClass({ fixed }: {
        fixed: any;
    }): {
        [x: string]: boolean;
    };
    getTheadThStyle({ _keys, align, fixed }: {
        _keys: any;
        align: any;
        fixed: any;
    }, rowIndex: any): {};
    getCheckboxContent(): JSX.Element | null;
    sortChange(): void;
    getSortContent(): JSX.Element | null;
    getFilterContent(): JSX.Element | null;
    getFilterCustomContent(): JSX.Element | null;
    cellClick(e: any, fn: any): void;
    cellDblclick(e: any, fn: any): void;
    cellContextmenu(e: any, fn: any): void;
    cellMouseenter(e: any, fn: any): void;
    cellMouseleave(e: any, fn: any): void;
    cellMousemove(e: any, fn: any): void;
    cellMouseover(e: any, fn: any): void;
    cellMousedown(e: any, fn: any): void;
    cellMouseup(e: any, fn: any): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    groupColumn: {
        type: ArrayConstructor;
        required: true;
    };
    groupColumnItem: {
        type: ObjectConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    headerRows: {
        type: ArrayConstructor;
        default(): never[];
    };
    fixedHeader: {
        type: BooleanConstructor;
    };
    isGroupHeader: {
        type: BooleanConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionRangeData: {
        type: ObjectConstructor;
        default(): null;
    };
    headerIndicatorColKeys: {
        type: ObjectConstructor;
        default(): null;
    };
    checkboxOption: {
        type: ObjectConstructor;
        default(): null;
    };
    sortOption: {
        type: ObjectConstructor;
        default(): null;
    };
    sortColumns: {
        type: ObjectConstructor;
        default(): null;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
}>>, {
    cellSelectionRangeData: Record<string, any>;
    headerIndicatorColKeys: Record<string, any>;
    cellSelectionData: Record<string, any>;
    checkboxOption: Record<string, any>;
    headerRows: unknown[];
    fixedHeader: boolean;
    sortOption: Record<string, any>;
    sortColumns: Record<string, any>;
    cellStyleOption: Record<string, any>;
    eventCustomOption: Record<string, any>;
}, {}>;
export default _default;
