declare const _default: import("vue").DefineComponent<{
    rowData: {
        type: ObjectConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSpanOption: {
        type: ObjectConstructor;
        default(): null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    footerRows: {
        type: ArrayConstructor;
        default(): never[];
    };
    fixedFooter: {
        type: BooleanConstructor;
        default: boolean;
    };
}, unknown, unknown, {
    currentRowKey(): any;
    trClass(): {
        [x: string]: boolean;
    };
}, {
    trHeightChange({ height }: {
        height: any;
    }): void;
    rowClick(e: any, fn: any): void;
    rowDblclick(e: any, fn: any): void;
    rowContextmenu(e: any, fn: any): void;
    rowMouseenter(e: any, fn: any): void;
    rowMouseleave(e: any, fn: any): void;
    rowMousemove(e: any, fn: any): void;
    rowMouseover(e: any, fn: any): void;
    rowMousedown(e: any, fn: any): void;
    rowMouseup(e: any, fn: any): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    rowData: {
        type: ObjectConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSpanOption: {
        type: ObjectConstructor;
        default(): null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    footerRows: {
        type: ArrayConstructor;
        default(): never[];
    };
    fixedFooter: {
        type: BooleanConstructor;
        default: boolean;
    };
}>>, {
    rowKeyFieldName: string;
    cellSelectionData: Record<string, any>;
    cellStyleOption: Record<string, any>;
    eventCustomOption: Record<string, any>;
    cellSpanOption: Record<string, any>;
    footerRows: unknown[];
    fixedFooter: boolean;
}, {}>;
export default _default;
