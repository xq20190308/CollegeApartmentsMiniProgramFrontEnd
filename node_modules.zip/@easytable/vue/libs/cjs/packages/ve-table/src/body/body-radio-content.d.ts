declare const _default: import("vue").DefineComponent<Readonly<import("vue").ComponentPropsOptions<{
    [x: string]: unknown;
}>>, unknown, {
    isSelected: boolean;
}, {
    disabled(): boolean | undefined;
    isControlledProp(): any;
}, {
    initSelected(): void;
    selectedChange(): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, readonly string[] | Readonly<globalThis.ExtractPropTypes<Readonly<import("vue").ComponentObjectPropsOptions<{
    [x: string]: unknown;
}>>>>, {
    [x: number]: string;
} | {}, {}>;
export default _default;
