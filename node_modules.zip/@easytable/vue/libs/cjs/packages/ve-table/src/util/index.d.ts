/**
 * @clsName
 * @desc  get class name
 * @param {string} cls - class
 */
export declare function clsName(cls: string): string;
/**
 * @getRowKey
 * @desc  get row key
 * @param {object} rowData - rowData
 * @param {string} rowKeyFieldName - row key field name
 */
export declare function getRowKey<T>(rowData: T, rowKeyFieldName: keyof T): T[keyof T] | null;
/**
 * @getColumnByColkey
 * @desc  get column by col key
 * @param {string} colKey - column key
 */
export declare function getColumnByColkey(colKey: string, colgroups: any): any;
/**
 * @isLastColumnByColKey
 * @desc is last column by column key
 * @param {string} colKey - column key
 */
export declare function isLastColumnByColKey(colKey: string, colgroups: any): boolean;
/**
 * @isOperationColumn
 * @desc is operation column
 * @param {string} colKey - column key
 * @param {arrat<object>} colgroups - column key
 */
export declare function isOperationColumn(colKey: string, colgroups: any): boolean;
/**
 * @isLastRowByRowKey
 * @desc is last row by row key
 * @param {string} rowKey - row key
 */
export declare function isLastRowByRowKey(rowKey: string, allRowKeys: string[]): boolean;
/**
 * @getDomResizeObserverCompKey
 * @desc  get dom resize observer comp key
 * @param {Any} originalKey - original key
 * @param {number} columnsOptionResetTime - columns option change time
 */
export declare function getDomResizeObserverCompKey(originalKey: any, columnsOptionResetTime: any): any;
/**
 * @recursiveRemoveColumnByKey
 * @desc recursive remove column key
 * @param {object} columns - deep clone column
 * @param {any} key - column key
 */
export declare function recursiveRemoveColumnByKey(columns: any, key: string): any;
/**
 * @getFixedTotalWidthByColumnKey
 * @desc  get fixed total width by column key
 * @param {object} colgroups - columns info
 * @param {any} colKey - column key
 * @param {string} fixed - left|right
 */
export declare function getFixedTotalWidthByColumnKey({ colgroups, colKey, fixed }: {
    colgroups: any;
    colKey: any;
    fixed: any;
}): number;
/**
 * @getNotFixedTotalWidthByColumnKey
 * @desc  get not fixed total width by column key
 * @param {object} colgroups - 列信息
 * @param {any} colKey - column key
 * @param {string} direction - left|right
 */
export declare function getNotFixedTotalWidthByColumnKey({ colgroups, colKey, fixed }: {
    colgroups: any;
    colKey: any;
    fixed: any;
}): number;
/**
 * @getTotalWidthByColKeys
 * @desc get total width by collumn keys
 * @param {Array<T>} colKeys
 * @param {Array<object>} colgroups
 * @return {number} width
 */
export declare function getTotalWidthByColKeys({ colKeys, colgroups }: {
    colKeys: any;
    colgroups: any;
}): any;
/**
 * @initGroupColumns
 * @desc  int group columns
 * @param {Array} cloneColumns - clone columns
 * @return {
   isGroupHeader,
   colgroups,
   groupColumns
}
 */
export declare function initGroupColumns(cloneColumns: any): {
    isGroupHeader: boolean;
    colgroups: any[];
    groupColumns: never[][];
};
export declare function getHeaderContextmenuOptionCollection(t: any): ({
    type: string;
    label?: undefined;
} | {
    label: any;
    type: any;
})[];
export declare function getBodyContextmenuOptionCollection(t: any): ({
    type: string;
    label?: undefined;
} | {
    label: any;
    type: any;
})[];
/***
 * @setHeaderContextmenuOptions
 * @desc set header contextmenu options
 * @param {array<object>} column
 * @param {array<object>} contextmenuHeaderOption
 * @param {object} cellSelectionRangeData
 * @param {array<object>} colgroups
 * @param {object} headerIndicatorColKeys
 * @param {boolean} enableHeaderContextmenu
 * @param {boolean} t locale
 * @return headerContextmenuOptions
 */
export declare function setHeaderContextmenuOptions({ column, contextmenuHeaderOption, cellSelectionRangeData, colgroups, allRowKeys, headerIndicatorColKeys, enableHeaderContextmenu, t, }: {
    column: any;
    contextmenuHeaderOption: any;
    cellSelectionRangeData: any;
    colgroups: any;
    allRowKeys: any;
    headerIndicatorColKeys: any;
    enableHeaderContextmenu: any;
    t: any;
}): any[];
/***
 * @setHeaderContextmenuOptions
 * @desc set header contextmenu options
 * @param {array<object>} column
 * @param {array<object>} contextmenuBodyOption
 * @param {object} cellSelectionRangeData
 * @param {array<object>} colgroups
 * @param {object} bodyIndicatorRowKeys
 * @param {boolean} enableHeaderContextmenu
 * @param {boolean} t locale
 * @return headerContextmenuOptions
 */
export declare function setBodyContextmenuOptions({ enableBodyContextmenu, contextmenuBodyOption, cellSelectionRangeData, colgroups, allRowKeys, bodyIndicatorRowKeys, t, }: {
    enableBodyContextmenu: any;
    contextmenuBodyOption: any;
    cellSelectionRangeData: any;
    colgroups: any;
    allRowKeys: any;
    bodyIndicatorRowKeys: any;
    t: any;
}): any[];
export declare function createEmptyRowData({ colgroups, rowKeyFieldName }: {
    colgroups: any;
    rowKeyFieldName: any;
}): {
    [x: number]: string;
};
export declare function isContextmenuPanelClicked(event: any): boolean;
/**
 * @getColKeysByHeaderColumn
 * @desc
 * @param {object} headerColumnItem
 * @param {any} colKey2
 * @return Array<colKeys>
 */
export declare function getColKeysByHeaderColumn({ headerColumnItem }: {
    headerColumnItem: any;
}): any;
/**
 * @getColKeysByRangeColKeys
 * @desc  get col keys by range col keys
 * @param {any} colKey1
 * @param {any} colKey2
 * @return Array<colKeys>
 */
export declare function getColKeysByRangeColKeys({ colKey1, colKey2, colgroups }: {
    colKey1: any;
    colKey2: any;
    colgroups: any;
}): any;
/**
 * @getColKeysByFixedTypeWithinColKeys
 * @desc  get col keys by fixed type
 * @param {Array<T>} colKeys
 * @param {string} fixedType - fixed type
 * @param {Array<object>} colgroups
 * @return {Array} colKeys
 */
export declare function getColKeysByFixedTypeWithinColKeys({ colKeys, fixedType, colgroups, }: {
    colKeys: any;
    fixedType: any;
    colgroups: any;
}): any;
/**
 * @getColKeysByFixedType
 * @desc get col keys by fixed type
 * @param {string} fixedType - fixed type
 * @param {Array<object>} colgroups
 * @param {boolean} isExcludeOperationColumn
 * @return colKey
 */
export declare function getColKeysByFixedType({ fixedType, colgroups, isExcludeOperationColumn, }: {
    fixedType: any;
    colgroups: any;
    isExcludeOperationColumn: any;
}): any;
/**
 * @getRowKeysByRangeRowKeys
 * @desc get row keys by range row keys
 * @param {any} topRowKey - top row key
 * @param {any} bottomRowKey - bottom row key
 * @return Array<colKeys>
 */
export declare function getRowKeysByRangeRowKeys({ topRowKey, bottomRowKey, allRowKeys, }: {
    topRowKey: any;
    bottomRowKey: any;
    allRowKeys: any;
}): any;
/**
 * @isCellInSelectionRange
 * @desc is cell in selection range
 * @param {object} cellData - cell data
 * @param {object} cellSelectionRangeData
 * @param {Array<object>} colgroups
 * @param {Array<object>} allRowKeys
 * @return {Array<colKeys>}
 */
export declare function isCellInSelectionRange({ cellData, cellSelectionRangeData, colgroups, allRowKeys, }: {
    cellData: any;
    cellSelectionRangeData: any;
    colgroups: any;
    allRowKeys: any;
}): boolean;
/**
 * @isClearSelectionByBodyCellRightClick
 * @desc is clear selection by body cell click
 * @param {number} mouseEventClickType
 * @param {object} cellData - cell data
 * @param {object} cellSelectionRangeData
 * @param {Array<object>} colgroups
 * @param {Array<object>} allRowKeys
 * @return {bool}
 */
export declare function isClearSelectionByBodyCellRightClick({ mouseEventClickType, cellData, cellSelectionData, cellSelectionRangeData, colgroups, allRowKeys, }: {
    mouseEventClickType: any;
    cellData: any;
    cellSelectionData: any;
    cellSelectionRangeData: any;
    colgroups: any;
    allRowKeys: any;
}): boolean;
/**
 * @getSelectionRangeKeys
 * @desc get selection range keys
 * @param {object} cellSelectionRangeData
 * @return Array<colKeys>
 */
export declare function getSelectionRangeKeys({ cellSelectionRangeData }: {
    cellSelectionRangeData: any;
}): {
    startColKey: any;
    endColKey: any;
    startRowKey: any;
    endRowKey: any;
};
/**
 * @getSelectionRangeIndexes
 * @desc get selection range indexes
 * @param {object} cellSelectionRangeData
 * @param {Array<object>} colgroups
 * @param {Array<object>} allRowKeys
 * @return Array<colKeys>
 */
export declare function getSelectionRangeIndexes({ cellSelectionRangeData, colgroups, allRowKeys, }: {
    cellSelectionRangeData: any;
    colgroups: any;
    allRowKeys: any;
}): {
    startColIndex: any;
    endColIndex: any;
    startRowIndex: any;
    endRowIndex: any;
};
/**
 * @getSelectionRangeData
 * @desc get selection range data
 * @param {object} cellSelectionRangeData
 * @param {string} resultType "normal": contains key/value ; "flat":only contains value
 * @param {Array<object>} tableData
 * @param {Array<object>} colgroups
 * @param {Array<object>} allRowKeys
 * @return Array<colKeys>
 */
export declare function getSelectionRangeData({ cellSelectionRangeData, resultType, tableData, colgroups, allRowKeys, }: {
    cellSelectionRangeData: any;
    resultType?: string | undefined;
    tableData: any;
    colgroups: any;
    allRowKeys: any;
}): any;
/**
 * @isExistFixedColKey
 * @desc is exist given fixed col key
 * @param {string} fixedType - fixed type
 * @param {Array<T>} colKeys
 * @param {Array<object>} colgroups
 * @return bool
 */
export declare function isExistGivenFixedColKey({ fixedType, colKeys, colgroups }: {
    fixedType: any;
    colKeys: any;
    colgroups: any;
}): boolean;
/**
 * @isExistNotFixedColKey
 * @desc is exist not fixed col key
 * @param {Array<T>} colKeys
 * @param {Array<object>} colgroups
 * @return bool
 */
export declare function isExistNotFixedColKey({ colKeys, colgroups }: {
    colKeys: any;
    colgroups: any;
}): boolean;
/**
 * @getLeftmostColKey
 * @desc get leftmost column key
 * @param {Array<object>} colgroups
 * @param {Array<any>} colKeys
 * @return colKey
 */
export declare function getLeftmostColKey({ colgroups, colKeys }: {
    colgroups: any;
    colKeys: any;
}): null;
/**
 * @getRightmostColKey
 * @desc get rightmost column key
 * @param {Array<object>} colgroups
 * @param {Array<any>} colKeys
 * @return colKey
 */
export declare function getRightmostColKey({ colgroups, colKeys }: {
    colgroups: any;
    colKeys: any;
}): null;
/**
 * @getPreviewColKey
 * @desc get preview column key
 * @param {Array<object>} colgroups
 * @param {any} currentColKey
 * @return colKey
 */
export declare function getPreviewColKey({ colgroups, currentColKey }: {
    colgroups: any;
    currentColKey: any;
}): any;
/**
 * @getNextColKey
 * @desc get next column key
 * @param {Array<object>} colgroups
 * @param {any} currentColKey
 * @return colKey
 */
export declare function getNextColKey({ colgroups, currentColKey }: {
    colgroups: any;
    currentColKey: any;
}): any;
/***
 * @cellAutofill
 * @desc cell auto fill
 * @param {bool} isReplaceData
 * @param {array<object>} tableData
 * @param {array<any>} allRowKeys
 * @param {array<object>} colgroups
 * @param {string} direction
 * @param {string} rowKeyFieldName
 * @param {object} nextCurrentCell next current cell
 * @param {object} nextNormalEndCell next normal end cell
 * @return autofillChangeDatas
 */
export declare function cellAutofill({ isReplaceData, tableData, allRowKeys, colgroups, direction, rowKeyFieldName, cellSelectionRangeData, nextCurrentCell, nextNormalEndCell, }: {
    isReplaceData: any;
    tableData: any;
    allRowKeys: any;
    colgroups: any;
    direction: any;
    rowKeyFieldName: any;
    cellSelectionRangeData: any;
    nextCurrentCell: any;
    nextNormalEndCell: any;
}): {
    direction: any;
    sourceSelectionRangeIndexes: {
        startRowIndex: number;
        endRowIndex: number;
        startColIndex: number;
        endColIndex: number;
    };
    targetSelectionRangeIndexes: {
        startRowIndex: number;
        endRowIndex: number;
        startColIndex: number;
        endColIndex: number;
    };
    sourceSelectionData: never[];
    targetSelectionData: never[];
};
/***
 * @setColumnFixed
 * @desc set column fixed
 * @param {array<object>} cloneColumns
 * @param {object} cellSelectionRangeData
 * @param {string} fixedType COLUMN_FIXED_TYPE
 * @param {array<object>} colgroups
 * @param {bool} enableColumnResize
 * @return cloneColumns
 */
export declare function setColumnFixed({ cloneColumns, cellSelectionRangeData, fixedType, colgroups, enableColumnResize, }: {
    cloneColumns: any;
    cellSelectionRangeData: any;
    fixedType: any;
    colgroups: any;
    enableColumnResize: any;
}): any;
/***
 * @cancelColumnFixed
 * @desc cancel column fixed
 * @param {array<object>} cloneColumns
 * @param {array<object>} colgroups
 * @param {string} fixedType COLUMN_FIXED_TYPE
 * @param {bool} enableColumnResize
 * @return cloneColumns
 */
export declare function cancelColumnFixed({ cloneColumns, colgroups, fixedType, enableColumnResize, }: {
    cloneColumns: any;
    colgroups: any;
    fixedType: any;
    enableColumnResize: any;
}): any;
/**
 * 转换 vue2 的事件名为 vue3
 * @param event emit 事件名 `on-aaa-bbb`
 * @returns 转换后 Vue3 jsx 的事件名 `onOnAaaBbb`
 */
export declare function getEmitEventName(event: string): string;
