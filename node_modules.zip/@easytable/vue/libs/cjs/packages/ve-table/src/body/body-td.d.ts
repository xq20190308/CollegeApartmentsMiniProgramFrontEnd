declare const _default: import("vue").DefineComponent<Readonly<import("vue").ComponentPropsOptions<{
    [x: string]: unknown;
}>>, unknown, {
    rawCellValue: string;
}, {
    currentColumnCollectionItem(): any;
    currentRowKey(): any;
}, {
    bodyTdStyle(): {};
    bodyTdClass(): {
        [x: string]: boolean;
    };
    getEllipsisContentStyle(): {};
    getRenderContent(h: any): any;
    getCheckboxContent(): JSX.Element | null;
    getRadioContent(): JSX.Element | null;
    getCellSpan(): {
        rowspan: number;
        colspan: number;
    };
    cellClick(e: any, fn: any): false | undefined;
    cellDblclick(e: any, fn: any): void;
    cellContextmenu(e: any, fn: any): void;
    cellMouseenter(e: any, fn: any): void;
    cellMouseleave(e: any, fn: any): void;
    cellMousemove(e: any, fn: any): void;
    cellMouseover(e: any, fn: any): void;
    cellMousedown(e: any, fn: any): void;
    cellMouseup(e: any, fn: any): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, readonly string[] | Readonly<globalThis.ExtractPropTypes<Readonly<import("vue").ComponentObjectPropsOptions<{
    [x: string]: unknown;
}>>>>, {
    [x: number]: string;
} | {}, {}>;
export default _default;
