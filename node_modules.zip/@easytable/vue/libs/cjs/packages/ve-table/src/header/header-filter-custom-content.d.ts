declare const _default: import("vue").DefineComponent<{
    column: {
        type: ObjectConstructor;
        required: true;
    };
}, unknown, {
    internalVisible: boolean;
}, {}, {
    visibleChange(visible: any): void;
    getCustomContent(h: any): JSX.Element | null;
    getIcon(h: any): any;
    close(): void;
    show(): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    column: {
        type: ObjectConstructor;
        required: true;
    };
}>>, {}, {}>;
export default _default;
