declare const _default: import("vue").DefineComponent<{
    column: {
        type: ObjectConstructor;
        required: true;
    };
}, unknown, {
    filterList: never[];
}, {}, {
    filterConfirm(): void;
    filterReset(): void;
    getIcon(h: any): any;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    column: {
        type: ObjectConstructor;
        required: true;
    };
}>>, {}, {}>;
export default _default;
