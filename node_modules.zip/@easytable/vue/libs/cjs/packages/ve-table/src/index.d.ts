declare const _default: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<readonly string[] | Readonly<globalThis.ExtractPropTypes<Readonly<import("vue").ComponentObjectPropsOptions<{
        [x: string]: unknown;
    }>>>>, unknown, {
        eventBus: import("mitt").Emitter<Record<import("mitt").EventType, unknown>>;
        hooks: {};
        parentRendered: boolean;
        tableViewportWidth: number;
        columnsOptionResetTime: number;
        tableRootRef: string;
        tableContainerWrapperRef: string;
        tableContainerRef: string;
        tableRef: string;
        tableBodyRef: string;
        tableContentWrapperRef: string;
        virtualPhantomRef: string;
        editInputRef: string;
        cellSelectionRef: string;
        contextmenuRef: string;
        cloneColumns: never[];
        isGroupHeader: boolean;
        headerRows: never[];
        footerRows: never[];
        colgroups: never[];
        groupColumns: never[];
        hiddenColumns: never[];
        virtualScrollVisibleData: never[];
        virtualScrollVisibleIndexs: {
            start: number;
            end: number;
        };
        defaultVirtualScrollBufferScale: number;
        defaultVirtualScrollMinRowHeight: number;
        defaultPlaceholderPerScrollingRowCount: number;
        virtualScrollStartIndex: number;
        previewVirtualScrollStartIndex: number;
        virtualScrollEndIndex: number;
        showVirtualScrollingPlaceholder: boolean;
        disablePointerEventsTimeoutId: null;
        isLeftScrolling: boolean;
        isRightScrolling: boolean;
        isVerticalScrolling: boolean;
        hasXScrollBar: boolean;
        hasYScrollBar: boolean;
        scrollBarWidth: number;
        previewTableContainerScrollLeft: null;
        headerIndicatorColKeys: {
            startColKey: string;
            startColKeyIndex: number;
            endColKey: string;
            endColKeyIndex: number;
        };
        bodyIndicatorRowKeys: {
            startRowKey: string;
            startRowKeyIndex: number;
            endRowKey: string;
            endRowKeyIndex: number;
        };
        cellSelectionData: {
            currentCell: {
                rowKey: string;
                colKey: string;
                rowIndex: number;
            };
            normalEndCell: {
                rowKey: string;
                colKey: string;
                rowIndex: number;
            };
            autoFillEndCell: {
                rowKey: string;
                colKey: string;
            };
        };
        cellSelectionRangeData: {
            leftColKey: string;
            rightColKey: string;
            topRowKey: string;
            bottomRowKey: string;
        };
        isHeaderCellMousedown: boolean;
        isBodyCellMousedown: boolean;
        isBodyOperationColumnMousedown: boolean;
        isAutofillStarting: boolean;
        autofillingDirection: null;
        currentCellSelectionType: string;
        tableOffestHeight: number;
        tableHeight: number;
        highlightRowKey: string;
        editingCell: {
            rowKey: string;
            colKey: string;
            row: null;
            column: null;
        };
        editorInputStartValue: string;
        enableStopEditing: boolean;
        contextmenuEventTarget: string;
        contextmenuOptions: never[];
        isColumnResizerHover: boolean;
        isColumnResizing: boolean;
    }, {
        actualRenderTableData(): never[] | ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
        allRowKeys(): any;
        virtualScrollBufferCount(): number;
        virtualScrollVisibleCount(): number;
        tableContainerWrapperStyle(): {
            width: string;
        };
        tableContainerStyle(): {
            'max-height': string;
            height: string | null;
        };
        tableStyle(): {
            width: string;
        };
        tableClass(): {
            [x: string]: ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
        };
        tableContainerClass(): {
            [x: string]: any;
        };
        tableBodyClass(): {
            [x: string]: boolean;
        };
        isVirtualScroll(): any;
        hasFixedColumn(): boolean;
        hasLeftFixedColumn(): boolean;
        hasRightFixedColumn(): boolean;
        isCellEditing(): boolean;
        hasEditColumn(): boolean;
        enableHeaderContextmenu(): boolean;
        enableBodyContextmenu(): boolean;
        contextMenuType(): string;
        enableCellSelection(): boolean;
        enableClipboard(): ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
        enableColumnResize(): boolean;
        headerTotalHeight(): number;
        footerTotalHeight(): number;
    }, {
        [x: string]: ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
        initHeaderRows(): void;
        initFooterRows(): void;
        headerRowHeightChange({ rowIndex, height }: {
            rowIndex: any;
            height: any;
        }): void;
        footRowHeightChange({ rowIndex, height }: {
            rowIndex: any;
            height: any;
        }): void;
        bodyCellWidthChange(colWidths: any): void;
        setColumnWidth({ colKey, width }: {
            colKey: any;
            width: any;
        }): void;
        updateColgroupsBySortChange(sortColumns: any): void;
        initColumnWidthByColumnResize(): void;
        initColumns(): void;
        showOrHideColumns(): void;
        initGroupColumns(): void;
        getScrollBarWidth(): number;
        selectedAllChange({ isSelected }: {
            isSelected: boolean;
        }): void;
        setSelectedAllInfo({ isSelected, isIndeterminate }: {
            isSelected: boolean;
            isIndeterminate: boolean;
        }): void;
        cellSelectionCurrentCellChange({ rowKey, colKey }: {
            rowKey: any;
            colKey: any;
        }): void;
        cellSelectionNormalEndCellChange({ rowKey, colKey }: {
            rowKey: any;
            colKey: any;
        }): void;
        cellSelectionAutofillCellChange({ rowKey, colKey }: {
            rowKey: any;
            colKey: any;
        }): void;
        clearCellSelectionCurrentCell(): void;
        clearCellSelectionNormalEndCell(): void;
        clearCellSelectionAutofillEndCell(): void;
        headerIndicatorColKeysChange({ startColKey, endColKey }: {
            startColKey: any;
            endColKey: any;
        }): void;
        clearHeaderIndicatorColKeys(): void;
        bodyIndicatorRowKeysChange({ startRowKey, endRowKey }: {
            startRowKey: any;
            endRowKey: any;
        }): void;
        clearBodyIndicatorRowKeys(): void;
        setCellSelectionByAutofill(): false | undefined;
        cellSelectionRangeDataChange(newData: any): void;
        autofillingDirectionChange(direction: any): void;
        setCurrentCellSelectionType(): void;
        dealKeydownEvent(event: any): void;
        selectCellByDirection({ direction }: {
            direction: any;
        }): void;
        columnToVisible(nextColumn: any): false | undefined;
        rowToVisible(keyCode: any, nextRowKey: any): void;
        setVirtualScrollVisibleData(): void;
        getVirtualScrollAboveCount(): number;
        getVirtualScrollBelowCount(): number;
        getVirtualViewPhantom(): JSX.Element | null;
        initVirtualScrollPositions(): void;
        bodyRowHeightChange({ rowKey, height }: {
            rowKey: any;
            height: any;
        }): void;
        setVirtualPhantomHeight(): void;
        setVirtualScrollStartOffset(): void;
        setTableContentTopValue({ top }: {
            top: any;
        }): void;
        getVirtualScrollStartIndex(scrollTop?: number): number | null;
        virtualScrollBinarySearch(list: any, value: any): number | null;
        tableContainerVirtualScrollHandler(tableContainerRef: any): void;
        debounceScrollEnded(): void;
        debounceScrollEndedCallback(): void;
        initVirtualScroll(): void;
        setScrolling(tableContainerRef: any): void;
        setScrollBarStatus(): void;
        initScrolling(): void;
        tableClickOutside(e: any): false | undefined;
        saveCellWhenStopEditing(): false | undefined;
        cellSelectionByClick({ rowData, column }: {
            rowData: any;
            column: any;
        }): void;
        bodyCellContextmenu({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): void;
        bodyCellDoubleClick({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): false | undefined;
        bodyCellClick({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): void;
        bodyCellMousedown({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): false | undefined;
        bodyCellMouseover({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): false | undefined;
        bodyCellMousemove({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): void;
        bodyCellMouseup({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): void;
        headerCellClick({ event, column }: {
            event: any;
            column: any;
        }): void;
        headerCellContextmenu({ event, column }: {
            event: any;
            column: any;
        }): void;
        setContextmenuOptions(column: any): void;
        headerCellMousedown({ event, column }: {
            event: any;
            column: any;
        }): false | undefined;
        headerCellMouseover({ event, column }: {
            event: any;
            column: any;
        }): void;
        headerCellMousemove({ event, column }: {
            event: any;
            column: any;
        }): void;
        headerCellMouseleave({ event, column }: {
            event: any;
            column: any;
        }): void;
        headerMouseleave(event: any): void;
        tableContainerMouseup(): void;
        cellSelectionCornerMousedown({ event }: {
            event: any;
        }): void;
        cellSelectionCornerMouseup({ event }: {
            event: any;
        }): void;
        isEditColumn(colKey: any): boolean;
        editCellByClick({ isDblclick, rowKey, colKey }: {
            isDblclick: any;
            rowKey: any;
            colKey: any;
        }): false | undefined;
        setEditingCell({ rowKey, colKey, column, row }: {
            rowKey: any;
            colKey: any;
            column: any;
            row: any;
        }): void;
        updateEditingCellValue(value: any): void;
        clearEditingCell(): void;
        contextmenuItemClick(type: any): void;
        headerContextmenuItemClick(type: any): false | undefined;
        bodyContextmenuItemClick(type: any): false | undefined;
        editorCopy(event: any): false | undefined;
        editorPaste(event: any): false | undefined;
        editorCut(event: any): false | undefined;
        deleteCellSelectionRangeValue(): false | undefined;
        setRangeCellSelectionByHeaderIndicator(): false | undefined;
        setRangeCellSelectionByBodyIndicator(): false | undefined;
        setIsColumnResizerHover(val: any): void;
        setIsColumnResizing(val: any): void;
    }, import("vue").DefineComponent<{}, {}, {}, {}, {
        dispatch(componentName: string, eventName: string, params: any): void;
        on(eventName: string, callback: (params: any) => void): void;
    }, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<readonly string[] | globalThis.ExtractPropTypes<Readonly<import("vue").ComponentObjectPropsOptions<{
        [x: string]: unknown;
    }>>>>, {
        [x: number]: string;
    } | {}, true, {}, {}, {
        P: Readonly<globalThis.ExtractPropTypes<{}>>;
        B: {};
        D: {};
        C: {};
        M: {
            dispatch(componentName: string, eventName: string, params: any): void;
            on(eventName: string, callback: (params: any) => void): void;
        };
        Defaults: {};
    } & {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<globalThis.ExtractPropTypes<{}>> & (readonly string[] | Readonly<globalThis.ExtractPropTypes<Readonly<import("vue").ComponentObjectPropsOptions<{
        [x: string]: unknown;
    }>>>>), {}, {
        eventBus: import("mitt").Emitter<Record<import("mitt").EventType, unknown>>;
        hooks: {};
        parentRendered: boolean;
        tableViewportWidth: number;
        columnsOptionResetTime: number;
        tableRootRef: string;
        tableContainerWrapperRef: string;
        tableContainerRef: string;
        tableRef: string;
        tableBodyRef: string;
        tableContentWrapperRef: string;
        virtualPhantomRef: string;
        editInputRef: string;
        cellSelectionRef: string;
        contextmenuRef: string;
        cloneColumns: never[];
        isGroupHeader: boolean;
        headerRows: never[];
        footerRows: never[];
        colgroups: never[];
        groupColumns: never[];
        hiddenColumns: never[];
        virtualScrollVisibleData: never[];
        virtualScrollVisibleIndexs: {
            start: number;
            end: number;
        };
        defaultVirtualScrollBufferScale: number;
        defaultVirtualScrollMinRowHeight: number;
        defaultPlaceholderPerScrollingRowCount: number;
        virtualScrollStartIndex: number;
        previewVirtualScrollStartIndex: number;
        virtualScrollEndIndex: number;
        showVirtualScrollingPlaceholder: boolean;
        disablePointerEventsTimeoutId: null;
        isLeftScrolling: boolean;
        isRightScrolling: boolean;
        isVerticalScrolling: boolean;
        hasXScrollBar: boolean;
        hasYScrollBar: boolean;
        scrollBarWidth: number;
        previewTableContainerScrollLeft: null;
        headerIndicatorColKeys: {
            startColKey: string;
            startColKeyIndex: number;
            endColKey: string;
            endColKeyIndex: number;
        };
        bodyIndicatorRowKeys: {
            startRowKey: string;
            startRowKeyIndex: number;
            endRowKey: string;
            endRowKeyIndex: number;
        };
        cellSelectionData: {
            currentCell: {
                rowKey: string;
                colKey: string;
                rowIndex: number;
            };
            normalEndCell: {
                rowKey: string;
                colKey: string;
                rowIndex: number;
            };
            autoFillEndCell: {
                rowKey: string;
                colKey: string;
            };
        };
        cellSelectionRangeData: {
            leftColKey: string;
            rightColKey: string;
            topRowKey: string;
            bottomRowKey: string;
        };
        isHeaderCellMousedown: boolean;
        isBodyCellMousedown: boolean;
        isBodyOperationColumnMousedown: boolean;
        isAutofillStarting: boolean;
        autofillingDirection: null;
        currentCellSelectionType: string;
        tableOffestHeight: number;
        tableHeight: number;
        highlightRowKey: string;
        editingCell: {
            rowKey: string;
            colKey: string;
            row: null;
            column: null;
        };
        editorInputStartValue: string;
        enableStopEditing: boolean;
        contextmenuEventTarget: string;
        contextmenuOptions: never[];
        isColumnResizerHover: boolean;
        isColumnResizing: boolean;
    }, {
        actualRenderTableData(): never[] | ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
        allRowKeys(): any;
        virtualScrollBufferCount(): number;
        virtualScrollVisibleCount(): number;
        tableContainerWrapperStyle(): {
            width: string;
        };
        tableContainerStyle(): {
            'max-height': string;
            height: string | null;
        };
        tableStyle(): {
            width: string;
        };
        tableClass(): {
            [x: string]: ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
        };
        tableContainerClass(): {
            [x: string]: any;
        };
        tableBodyClass(): {
            [x: string]: boolean;
        };
        isVirtualScroll(): any;
        hasFixedColumn(): boolean;
        hasLeftFixedColumn(): boolean;
        hasRightFixedColumn(): boolean;
        isCellEditing(): boolean;
        hasEditColumn(): boolean;
        enableHeaderContextmenu(): boolean;
        enableBodyContextmenu(): boolean;
        contextMenuType(): string;
        enableCellSelection(): boolean;
        enableClipboard(): ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
        enableColumnResize(): boolean;
        headerTotalHeight(): number;
        footerTotalHeight(): number;
    }, {
        dispatch(componentName: string, eventName: string, params: any): void;
        on(eventName: string, callback: (params: any) => void): void;
    } & {
        [x: string]: ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
        initHeaderRows(): void;
        initFooterRows(): void;
        headerRowHeightChange({ rowIndex, height }: {
            rowIndex: any;
            height: any;
        }): void;
        footRowHeightChange({ rowIndex, height }: {
            rowIndex: any;
            height: any;
        }): void;
        bodyCellWidthChange(colWidths: any): void;
        setColumnWidth({ colKey, width }: {
            colKey: any;
            width: any;
        }): void;
        updateColgroupsBySortChange(sortColumns: any): void;
        initColumnWidthByColumnResize(): void;
        initColumns(): void;
        showOrHideColumns(): void;
        initGroupColumns(): void;
        getScrollBarWidth(): number;
        selectedAllChange({ isSelected }: {
            isSelected: boolean;
        }): void;
        setSelectedAllInfo({ isSelected, isIndeterminate }: {
            isSelected: boolean;
            isIndeterminate: boolean;
        }): void;
        cellSelectionCurrentCellChange({ rowKey, colKey }: {
            rowKey: any;
            colKey: any;
        }): void;
        cellSelectionNormalEndCellChange({ rowKey, colKey }: {
            rowKey: any;
            colKey: any;
        }): void;
        cellSelectionAutofillCellChange({ rowKey, colKey }: {
            rowKey: any;
            colKey: any;
        }): void;
        clearCellSelectionCurrentCell(): void;
        clearCellSelectionNormalEndCell(): void;
        clearCellSelectionAutofillEndCell(): void;
        headerIndicatorColKeysChange({ startColKey, endColKey }: {
            startColKey: any;
            endColKey: any;
        }): void;
        clearHeaderIndicatorColKeys(): void;
        bodyIndicatorRowKeysChange({ startRowKey, endRowKey }: {
            startRowKey: any;
            endRowKey: any;
        }): void;
        clearBodyIndicatorRowKeys(): void;
        setCellSelectionByAutofill(): false | undefined;
        cellSelectionRangeDataChange(newData: any): void;
        autofillingDirectionChange(direction: any): void;
        setCurrentCellSelectionType(): void;
        dealKeydownEvent(event: any): void;
        selectCellByDirection({ direction }: {
            direction: any;
        }): void;
        columnToVisible(nextColumn: any): false | undefined;
        rowToVisible(keyCode: any, nextRowKey: any): void;
        setVirtualScrollVisibleData(): void;
        getVirtualScrollAboveCount(): number;
        getVirtualScrollBelowCount(): number;
        getVirtualViewPhantom(): JSX.Element | null;
        initVirtualScrollPositions(): void;
        bodyRowHeightChange({ rowKey, height }: {
            rowKey: any;
            height: any;
        }): void;
        setVirtualPhantomHeight(): void;
        setVirtualScrollStartOffset(): void;
        setTableContentTopValue({ top }: {
            top: any;
        }): void;
        getVirtualScrollStartIndex(scrollTop?: number): number | null;
        virtualScrollBinarySearch(list: any, value: any): number | null;
        tableContainerVirtualScrollHandler(tableContainerRef: any): void;
        debounceScrollEnded(): void;
        debounceScrollEndedCallback(): void;
        initVirtualScroll(): void;
        setScrolling(tableContainerRef: any): void;
        setScrollBarStatus(): void;
        initScrolling(): void;
        tableClickOutside(e: any): false | undefined;
        saveCellWhenStopEditing(): false | undefined;
        cellSelectionByClick({ rowData, column }: {
            rowData: any;
            column: any;
        }): void;
        bodyCellContextmenu({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): void;
        bodyCellDoubleClick({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): false | undefined;
        bodyCellClick({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): void;
        bodyCellMousedown({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): false | undefined;
        bodyCellMouseover({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): false | undefined;
        bodyCellMousemove({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): void;
        bodyCellMouseup({ event, rowData, column }: {
            event: any;
            rowData: any;
            column: any;
        }): void;
        headerCellClick({ event, column }: {
            event: any;
            column: any;
        }): void;
        headerCellContextmenu({ event, column }: {
            event: any;
            column: any;
        }): void;
        setContextmenuOptions(column: any): void;
        headerCellMousedown({ event, column }: {
            event: any;
            column: any;
        }): false | undefined;
        headerCellMouseover({ event, column }: {
            event: any;
            column: any;
        }): void;
        headerCellMousemove({ event, column }: {
            event: any;
            column: any;
        }): void;
        headerCellMouseleave({ event, column }: {
            event: any;
            column: any;
        }): void;
        headerMouseleave(event: any): void;
        tableContainerMouseup(): void;
        cellSelectionCornerMousedown({ event }: {
            event: any;
        }): void;
        cellSelectionCornerMouseup({ event }: {
            event: any;
        }): void;
        isEditColumn(colKey: any): boolean;
        editCellByClick({ isDblclick, rowKey, colKey }: {
            isDblclick: any;
            rowKey: any;
            colKey: any;
        }): false | undefined;
        setEditingCell({ rowKey, colKey, column, row }: {
            rowKey: any;
            colKey: any;
            column: any;
            row: any;
        }): void;
        updateEditingCellValue(value: any): void;
        clearEditingCell(): void;
        contextmenuItemClick(type: any): void;
        headerContextmenuItemClick(type: any): false | undefined;
        bodyContextmenuItemClick(type: any): false | undefined;
        editorCopy(event: any): false | undefined;
        editorPaste(event: any): false | undefined;
        editorCut(event: any): false | undefined;
        deleteCellSelectionRangeValue(): false | undefined;
        setRangeCellSelectionByHeaderIndicator(): false | undefined;
        setRangeCellSelectionByBodyIndicator(): false | undefined;
        setIsColumnResizerHover(val: any): void;
        setIsColumnResizing(val: any): void;
    }, {} & ({
        [x: number]: string;
    } | {})>;
    __isFragment?: undefined;
    __isTeleport?: undefined;
    __isSuspense?: undefined;
} & import("vue").ComponentOptionsBase<readonly string[] | Readonly<globalThis.ExtractPropTypes<Readonly<import("vue").ComponentObjectPropsOptions<{
    [x: string]: unknown;
}>>>>, unknown, {
    eventBus: import("mitt").Emitter<Record<import("mitt").EventType, unknown>>;
    hooks: {};
    parentRendered: boolean;
    tableViewportWidth: number;
    columnsOptionResetTime: number;
    tableRootRef: string;
    tableContainerWrapperRef: string;
    tableContainerRef: string;
    tableRef: string;
    tableBodyRef: string;
    tableContentWrapperRef: string;
    virtualPhantomRef: string;
    editInputRef: string;
    cellSelectionRef: string;
    contextmenuRef: string;
    cloneColumns: never[];
    isGroupHeader: boolean;
    headerRows: never[];
    footerRows: never[];
    colgroups: never[];
    groupColumns: never[];
    hiddenColumns: never[];
    virtualScrollVisibleData: never[];
    virtualScrollVisibleIndexs: {
        start: number;
        end: number;
    };
    defaultVirtualScrollBufferScale: number;
    defaultVirtualScrollMinRowHeight: number;
    defaultPlaceholderPerScrollingRowCount: number;
    virtualScrollStartIndex: number;
    previewVirtualScrollStartIndex: number;
    virtualScrollEndIndex: number;
    showVirtualScrollingPlaceholder: boolean;
    disablePointerEventsTimeoutId: null;
    isLeftScrolling: boolean;
    isRightScrolling: boolean;
    isVerticalScrolling: boolean;
    hasXScrollBar: boolean;
    hasYScrollBar: boolean;
    scrollBarWidth: number;
    previewTableContainerScrollLeft: null;
    headerIndicatorColKeys: {
        startColKey: string;
        startColKeyIndex: number;
        endColKey: string;
        endColKeyIndex: number;
    };
    bodyIndicatorRowKeys: {
        startRowKey: string;
        startRowKeyIndex: number;
        endRowKey: string;
        endRowKeyIndex: number;
    };
    cellSelectionData: {
        currentCell: {
            rowKey: string;
            colKey: string;
            rowIndex: number;
        };
        normalEndCell: {
            rowKey: string;
            colKey: string;
            rowIndex: number;
        };
        autoFillEndCell: {
            rowKey: string;
            colKey: string;
        };
    };
    cellSelectionRangeData: {
        leftColKey: string;
        rightColKey: string;
        topRowKey: string;
        bottomRowKey: string;
    };
    isHeaderCellMousedown: boolean;
    isBodyCellMousedown: boolean;
    isBodyOperationColumnMousedown: boolean;
    isAutofillStarting: boolean;
    autofillingDirection: null;
    currentCellSelectionType: string;
    tableOffestHeight: number;
    tableHeight: number;
    highlightRowKey: string;
    editingCell: {
        rowKey: string;
        colKey: string;
        row: null;
        column: null;
    };
    editorInputStartValue: string;
    enableStopEditing: boolean;
    contextmenuEventTarget: string;
    contextmenuOptions: never[];
    isColumnResizerHover: boolean;
    isColumnResizing: boolean;
}, {
    actualRenderTableData(): never[] | ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
    allRowKeys(): any;
    virtualScrollBufferCount(): number;
    virtualScrollVisibleCount(): number;
    tableContainerWrapperStyle(): {
        width: string;
    };
    tableContainerStyle(): {
        'max-height': string;
        height: string | null;
    };
    tableStyle(): {
        width: string;
    };
    tableClass(): {
        [x: string]: ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
    };
    tableContainerClass(): {
        [x: string]: any;
    };
    tableBodyClass(): {
        [x: string]: boolean;
    };
    isVirtualScroll(): any;
    hasFixedColumn(): boolean;
    hasLeftFixedColumn(): boolean;
    hasRightFixedColumn(): boolean;
    isCellEditing(): boolean;
    hasEditColumn(): boolean;
    enableHeaderContextmenu(): boolean;
    enableBodyContextmenu(): boolean;
    contextMenuType(): string;
    enableCellSelection(): boolean;
    enableClipboard(): ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
    enableColumnResize(): boolean;
    headerTotalHeight(): number;
    footerTotalHeight(): number;
}, {
    [x: string]: ((keyCode: any, nextRowKey: any) => void) | ((scrollTop?: number) => number | null);
    initHeaderRows(): void;
    initFooterRows(): void;
    headerRowHeightChange({ rowIndex, height }: {
        rowIndex: any;
        height: any;
    }): void;
    footRowHeightChange({ rowIndex, height }: {
        rowIndex: any;
        height: any;
    }): void;
    bodyCellWidthChange(colWidths: any): void;
    setColumnWidth({ colKey, width }: {
        colKey: any;
        width: any;
    }): void;
    updateColgroupsBySortChange(sortColumns: any): void;
    initColumnWidthByColumnResize(): void;
    initColumns(): void;
    showOrHideColumns(): void;
    initGroupColumns(): void;
    getScrollBarWidth(): number;
    selectedAllChange({ isSelected }: {
        isSelected: boolean;
    }): void;
    setSelectedAllInfo({ isSelected, isIndeterminate }: {
        isSelected: boolean;
        isIndeterminate: boolean;
    }): void;
    cellSelectionCurrentCellChange({ rowKey, colKey }: {
        rowKey: any;
        colKey: any;
    }): void;
    cellSelectionNormalEndCellChange({ rowKey, colKey }: {
        rowKey: any;
        colKey: any;
    }): void;
    cellSelectionAutofillCellChange({ rowKey, colKey }: {
        rowKey: any;
        colKey: any;
    }): void;
    clearCellSelectionCurrentCell(): void;
    clearCellSelectionNormalEndCell(): void;
    clearCellSelectionAutofillEndCell(): void;
    headerIndicatorColKeysChange({ startColKey, endColKey }: {
        startColKey: any;
        endColKey: any;
    }): void;
    clearHeaderIndicatorColKeys(): void;
    bodyIndicatorRowKeysChange({ startRowKey, endRowKey }: {
        startRowKey: any;
        endRowKey: any;
    }): void;
    clearBodyIndicatorRowKeys(): void;
    setCellSelectionByAutofill(): false | undefined;
    cellSelectionRangeDataChange(newData: any): void;
    autofillingDirectionChange(direction: any): void;
    setCurrentCellSelectionType(): void;
    dealKeydownEvent(event: any): void;
    selectCellByDirection({ direction }: {
        direction: any;
    }): void;
    columnToVisible(nextColumn: any): false | undefined;
    rowToVisible(keyCode: any, nextRowKey: any): void;
    setVirtualScrollVisibleData(): void;
    getVirtualScrollAboveCount(): number;
    getVirtualScrollBelowCount(): number;
    getVirtualViewPhantom(): JSX.Element | null;
    initVirtualScrollPositions(): void;
    bodyRowHeightChange({ rowKey, height }: {
        rowKey: any;
        height: any;
    }): void;
    setVirtualPhantomHeight(): void;
    setVirtualScrollStartOffset(): void;
    setTableContentTopValue({ top }: {
        top: any;
    }): void;
    getVirtualScrollStartIndex(scrollTop?: number): number | null;
    virtualScrollBinarySearch(list: any, value: any): number | null;
    tableContainerVirtualScrollHandler(tableContainerRef: any): void;
    debounceScrollEnded(): void;
    debounceScrollEndedCallback(): void;
    initVirtualScroll(): void;
    setScrolling(tableContainerRef: any): void;
    setScrollBarStatus(): void;
    initScrolling(): void;
    tableClickOutside(e: any): false | undefined;
    saveCellWhenStopEditing(): false | undefined;
    cellSelectionByClick({ rowData, column }: {
        rowData: any;
        column: any;
    }): void;
    bodyCellContextmenu({ event, rowData, column }: {
        event: any;
        rowData: any;
        column: any;
    }): void;
    bodyCellDoubleClick({ event, rowData, column }: {
        event: any;
        rowData: any;
        column: any;
    }): false | undefined;
    bodyCellClick({ event, rowData, column }: {
        event: any;
        rowData: any;
        column: any;
    }): void;
    bodyCellMousedown({ event, rowData, column }: {
        event: any;
        rowData: any;
        column: any;
    }): false | undefined;
    bodyCellMouseover({ event, rowData, column }: {
        event: any;
        rowData: any;
        column: any;
    }): false | undefined;
    bodyCellMousemove({ event, rowData, column }: {
        event: any;
        rowData: any;
        column: any;
    }): void;
    bodyCellMouseup({ event, rowData, column }: {
        event: any;
        rowData: any;
        column: any;
    }): void;
    headerCellClick({ event, column }: {
        event: any;
        column: any;
    }): void;
    headerCellContextmenu({ event, column }: {
        event: any;
        column: any;
    }): void;
    setContextmenuOptions(column: any): void;
    headerCellMousedown({ event, column }: {
        event: any;
        column: any;
    }): false | undefined;
    headerCellMouseover({ event, column }: {
        event: any;
        column: any;
    }): void;
    headerCellMousemove({ event, column }: {
        event: any;
        column: any;
    }): void;
    headerCellMouseleave({ event, column }: {
        event: any;
        column: any;
    }): void;
    headerMouseleave(event: any): void;
    tableContainerMouseup(): void;
    cellSelectionCornerMousedown({ event }: {
        event: any;
    }): void;
    cellSelectionCornerMouseup({ event }: {
        event: any;
    }): void;
    isEditColumn(colKey: any): boolean;
    editCellByClick({ isDblclick, rowKey, colKey }: {
        isDblclick: any;
        rowKey: any;
        colKey: any;
    }): false | undefined;
    setEditingCell({ rowKey, colKey, column, row }: {
        rowKey: any;
        colKey: any;
        column: any;
        row: any;
    }): void;
    updateEditingCellValue(value: any): void;
    clearEditingCell(): void;
    contextmenuItemClick(type: any): void;
    headerContextmenuItemClick(type: any): false | undefined;
    bodyContextmenuItemClick(type: any): false | undefined;
    editorCopy(event: any): false | undefined;
    editorPaste(event: any): false | undefined;
    editorCut(event: any): false | undefined;
    deleteCellSelectionRangeValue(): false | undefined;
    setRangeCellSelectionByHeaderIndicator(): false | undefined;
    setRangeCellSelectionByBodyIndicator(): false | undefined;
    setIsColumnResizerHover(val: any): void;
    setIsColumnResizing(val: any): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, {
    [x: number]: string;
} | {}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin<any[]>;
export default _default;
