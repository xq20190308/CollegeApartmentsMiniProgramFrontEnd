import type { PropType } from 'vue';
declare const _default: import("vue").DefineComponent<{
    colgroups: {
        type: PropType<any[]>;
        required: true;
    };
    enableColumnResize: {
        type: BooleanConstructor;
        required: true;
    };
}, unknown, unknown, {}, {
    getValByUnit(item: any): string;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    colgroups: {
        type: PropType<any[]>;
        required: true;
    };
    enableColumnResize: {
        type: BooleanConstructor;
        required: true;
    };
}>>, {}, {}>;
export default _default;
