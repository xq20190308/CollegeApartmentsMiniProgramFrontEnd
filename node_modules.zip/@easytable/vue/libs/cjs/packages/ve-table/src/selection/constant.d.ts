export declare const INSTANCE_METHODS: {
    CLEAR_CURRENT_CELL_RECT: string;
    CLEAR_NORMAL_END_CELL_RECT: string;
};
