declare const _default: {
    name: string;
    props: {
        colgroups: {
            type: ArrayConstructor;
            required: boolean;
        };
        footerData: {
            type: ArrayConstructor;
            required: boolean;
        };
        hasFixedColumn: {
            type: BooleanConstructor;
            default: boolean;
        };
        allRowKeys: {
            type: ArrayConstructor;
            required: boolean;
        };
        rowKeyFieldName: {
            type: StringConstructor;
            default: null;
        };
        cellStyleOption: {
            type: ObjectConstructor;
            default(): null;
        };
        eventCustomOption: {
            type: ObjectConstructor;
            default(): null;
        };
        footerRows: {
            type: ArrayConstructor;
            default(): never[];
        };
        fixedFooter: {
            type: BooleanConstructor;
            default: boolean;
        };
        cellSpanOption: {
            type: ObjectConstructor;
            default(): null;
        };
    };
    computed: {
        footerClass(): any;
    };
    methods: {
        getTrKey({ rowData, rowIndex }: {
            rowData: any;
            rowIndex: any;
        }): any;
    };
    render(): JSX.Element;
};
export default _default;
