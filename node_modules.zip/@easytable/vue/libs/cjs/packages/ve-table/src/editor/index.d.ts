declare const _default: import("vue").DefineComponent<{
    parentRendered: {
        type: BooleanConstructor;
        required: true;
    };
    hooks: {
        type: ObjectConstructor;
        required: true;
    };
    inputStartValue: {
        type: (StringConstructor | NumberConstructor)[];
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
    tableData: {
        type: ArrayConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        required: true;
    };
    editingCell: {
        type: ObjectConstructor;
        required: true;
    };
    isCellEditing: {
        type: BooleanConstructor;
        required: true;
    };
    hasXScrollBar: {
        type: BooleanConstructor;
        required: true;
    };
    hasYScrollBar: {
        type: BooleanConstructor;
        required: true;
    };
    hasRightFixedColumn: {
        type: BooleanConstructor;
        required: true;
    };
    scrollBarWidth: {
        type: NumberConstructor;
        required: true;
    };
}, unknown, {
    textareaInputRef: string;
    rawCellValue: string;
    displayTextarea: boolean;
    overflowViewport: boolean;
    textareaRect: {
        left: number;
        top: number;
    };
    tableEl: null;
    cellEl: null;
    autoResize: null;
    isEditCellFocus: boolean;
}, {
    currentColumn(): unknown;
    containerClass(): {
        [x: string]: boolean;
    };
    containerStyle(): {};
    textareaClass(): {
        [x: string]: boolean;
    };
}, {
    [x: string]: (val: any) => void;
    setTableEl(): void;
    setCellEl(): void;
    setTextareaPosition(): void;
    showTextarea(): void;
    hideTextarea(): void;
    textareaUnObserve(): void;
    setRawCellValue(): void;
    textareaValueChange(val: any): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    parentRendered: {
        type: BooleanConstructor;
        required: true;
    };
    hooks: {
        type: ObjectConstructor;
        required: true;
    };
    inputStartValue: {
        type: (StringConstructor | NumberConstructor)[];
        required: true;
    };
    rowKeyFieldName: {
        type: StringConstructor;
        default: null;
    };
    tableData: {
        type: ArrayConstructor;
        required: true;
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        required: true;
    };
    editingCell: {
        type: ObjectConstructor;
        required: true;
    };
    isCellEditing: {
        type: BooleanConstructor;
        required: true;
    };
    hasXScrollBar: {
        type: BooleanConstructor;
        required: true;
    };
    hasYScrollBar: {
        type: BooleanConstructor;
        required: true;
    };
    hasRightFixedColumn: {
        type: BooleanConstructor;
        required: true;
    };
    scrollBarWidth: {
        type: NumberConstructor;
        required: true;
    };
}>>, {
    rowKeyFieldName: string;
}, {}>;
export default _default;
