/**
 * @decodeSpreadsheetStr
 * @desc Decode spreadsheet string into array.  refer from http://github.com/warpech/sheetclip/
 * @param {string} str The string to parse.
 */
export declare function decodeSpreadsheetStr(str: string): string[][];
/**
 * @decodeSpreadsheetStr
 * @desc encode array to spreadsheet string.  refer from http://github.com/warpech/sheetclip/
 * @param {Array} arr The string to parse.
 */
export declare function encodeToSpreadsheetStr(arr: any[]): string;
/**
 * @onBeforeCopy
 * @desc on before copy
 * @param {Event} event
 * @return {selectionRangeIndexes,selectionRangeKeys,data}
 */
export declare function onBeforeCopy({ cellSelectionRangeData, selectionRangeData, colgroups, allRowKeys, }: any): {
    selectionRangeIndexes: {
        startColIndex: any;
        endColIndex: any;
        startRowIndex: any;
        endRowIndex: any;
    };
    selectionRangeKeys: {
        startColKey: any;
        endColKey: any;
        startRowKey: any;
        endRowKey: any;
    };
    data: any;
};
/**
 * @onAfterCopy
 * @desc on after copy
 * @param {Event} event
 * @return
 */
export declare function onAfterCopy({ event, selectionRangeData }: any): void;
/**
 * @onBeforePaste
 * @desc on before paste
 * @param {Event} event
 * @return
 */
export declare function onBeforePaste({ event, cellSelectionRangeData, colgroups, allRowKeys, }: any): {
    selectionRangeIndexes: {
        startColIndex: any;
        endColIndex: number;
        startRowIndex: any;
        endRowIndex: number;
    };
    selectionRangeKeys: {
        startColKey: any;
        endColKey: any;
        startRowKey: any;
        endRowKey: any;
    };
    data: never[];
} | null;
/**
 * @onAfterPaste
 * @desc on after paste
 * @param {Event} event
 * @return
 */
export declare function onAfterPaste({ tableData, beforePasteResponse }: {
    tableData: any;
    beforePasteResponse: any;
}): void;
/**
 * @onBeforeCut
 * @desc on before cut
 * @param {Event} event
 * @return {selectionRangeIndexes,selectionRangeKeys,data}
 */
export declare function onBeforeCut({ cellSelectionRangeData, selectionRangeData, colgroups, allRowKeys, }: {
    cellSelectionRangeData: any;
    selectionRangeData: any;
    colgroups: any;
    allRowKeys: any;
}): {
    selectionRangeIndexes: {
        startColIndex: any;
        endColIndex: any;
        startRowIndex: any;
        endRowIndex: any;
    };
    selectionRangeKeys: {
        startColKey: any;
        endColKey: any;
        startRowKey: any;
        endRowKey: any;
    };
    data: any;
};
/**
 * @onAfterCut
 * @desc on after cut
 * @param {Event} event
 * @return
 */
export declare function onAfterCut({ event, tableData, colgroups, selectionRangeData, selectionRangeIndexes, }: {
    event: any;
    tableData: any;
    colgroups: any;
    selectionRangeData: any;
    selectionRangeIndexes: any;
}): void;
/**
 * @onBeforeDelete
 * @desc on before delete
 * @param {Event} event
 * @return {selectionRangeIndexes,selectionRangeKeys,data}
 */
export declare function onBeforeDelete({ cellSelectionRangeData, selectionRangeData, colgroups, allRowKeys, }: {
    cellSelectionRangeData: any;
    selectionRangeData: any;
    colgroups: any;
    allRowKeys: any;
}): {
    selectionRangeIndexes: {
        startColIndex: any;
        endColIndex: any;
        startRowIndex: any;
        endRowIndex: any;
    };
    selectionRangeKeys: {
        startColKey: any;
        endColKey: any;
        startRowKey: any;
        endRowKey: any;
    };
    data: any;
};
/**
 * @onAfterDelete
 * @desc on after delete
 * @param {Event} event
 * @return
 */
export declare function onAfterDelete({ tableData, colgroups, selectionRangeIndexes }: {
    tableData: any;
    colgroups: any;
    selectionRangeIndexes: any;
}): void;
