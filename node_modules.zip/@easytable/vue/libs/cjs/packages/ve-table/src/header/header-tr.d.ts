declare const _default: import("vue").DefineComponent<{
    columnsOptionResetTime: {
        type: NumberConstructor;
        default: number;
    };
    groupColumn: {
        type: ArrayConstructor;
        required: true;
    };
    headerRows: {
        type: ArrayConstructor;
        default(): never[];
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    fixedHeader: {
        type: BooleanConstructor;
        required: true;
    };
    isGroupHeader: {
        type: BooleanConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionRangeData: {
        type: ObjectConstructor;
        default(): null;
    };
    headerIndicatorColKeys: {
        type: ObjectConstructor;
        default(): null;
    };
    checkboxOption: {
        type: ObjectConstructor;
        default(): null;
    };
    sortOption: {
        type: ObjectConstructor;
        default(): null;
    };
    sortColumns: {
        type: ObjectConstructor;
        default(): null;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
}, unknown, unknown, {}, {
    trHeightChange({ height }: {
        height: any;
    }): void;
    rowClick(e: any, fn: any): void;
    rowDblclick(e: any, fn: any): void;
    rowContextmenu(e: any, fn: any): void;
    rowMouseenter(e: any, fn: any): void;
    rowMouseleave(e: any, fn: any): void;
    rowMousemove(e: any, fn: any): void;
    rowMouseover(e: any, fn: any): void;
    rowMousedown(e: any, fn: any): void;
    rowMouseup(e: any, fn: any): void;
}, import("vue").DefineComponent<{}, {}, {}, {}, {
    dispatch(componentName: string, eventName: string, params: any): void;
    on(eventName: string, callback: (params: any) => void): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {}>, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    columnsOptionResetTime: {
        type: NumberConstructor;
        default: number;
    };
    groupColumn: {
        type: ArrayConstructor;
        required: true;
    };
    headerRows: {
        type: ArrayConstructor;
        default(): never[];
    };
    colgroups: {
        type: ArrayConstructor;
        required: true;
    };
    fixedHeader: {
        type: BooleanConstructor;
        required: true;
    };
    isGroupHeader: {
        type: BooleanConstructor;
        required: true;
    };
    rowIndex: {
        type: NumberConstructor;
        required: true;
    };
    cellSelectionData: {
        type: ObjectConstructor;
        default(): null;
    };
    cellSelectionRangeData: {
        type: ObjectConstructor;
        default(): null;
    };
    headerIndicatorColKeys: {
        type: ObjectConstructor;
        default(): null;
    };
    checkboxOption: {
        type: ObjectConstructor;
        default(): null;
    };
    sortOption: {
        type: ObjectConstructor;
        default(): null;
    };
    sortColumns: {
        type: ObjectConstructor;
        default(): null;
    };
    cellStyleOption: {
        type: ObjectConstructor;
        default(): null;
    };
    eventCustomOption: {
        type: ObjectConstructor;
        default(): null;
    };
}>>, {
    cellSelectionRangeData: Record<string, any>;
    headerIndicatorColKeys: Record<string, any>;
    cellSelectionData: Record<string, any>;
    checkboxOption: Record<string, any>;
    headerRows: unknown[];
    sortOption: Record<string, any>;
    sortColumns: Record<string, any>;
    cellStyleOption: Record<string, any>;
    eventCustomOption: Record<string, any>;
    columnsOptionResetTime: number;
}, {}>;
export default _default;
