export declare const PREFIX_CLS = "ve-checkbox-group-";
export declare const EMIT_EVENTS: {
    ON_CHECKED_CHANGE: string;
};
export declare const COMPS_NAME: {
    VE_CHECKBOX: string;
    VE_CHECKBOX_GROUP: string;
};
