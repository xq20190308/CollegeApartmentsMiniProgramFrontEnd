export declare function clsName(cls: string): string;
