export declare const PREFIX_CLS = "ve-icon-";
export declare const EMIT_EVENTS: {};
export declare const COMPS_NAME: {
    VE_ICON: string;
};
