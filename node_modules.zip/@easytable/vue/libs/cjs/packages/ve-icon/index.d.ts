declare const _default: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<globalThis.ExtractPropTypes<{
        name: {
            type: StringConstructor;
            required: true;
        };
        color: {
            type: StringConstructor;
            default: null;
        };
        size: {
            type: (StringConstructor | NumberConstructor)[];
            default: string;
        };
    }>>, unknown, unknown, {
        iconStyle(): {
            color: string;
            'font-size': string;
        };
        iconClass(): string;
    }, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<globalThis.ExtractPropTypes<{
        name: {
            type: StringConstructor;
            required: true;
        };
        color: {
            type: StringConstructor;
            default: null;
        };
        size: {
            type: (StringConstructor | NumberConstructor)[];
            default: string;
        };
    }>>, {
        size: string | number;
        color: string;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<globalThis.ExtractPropTypes<{
        name: {
            type: StringConstructor;
            required: true;
        };
        color: {
            type: StringConstructor;
            default: null;
        };
        size: {
            type: (StringConstructor | NumberConstructor)[];
            default: string;
        };
    }>>, {}, {}, {
        iconStyle(): {
            color: string;
            'font-size': string;
        };
        iconClass(): string;
    }, {}, {
        size: string | number;
        color: string;
    }>;
    __isFragment?: undefined;
    __isTeleport?: undefined;
    __isSuspense?: undefined;
} & import("vue").ComponentOptionsBase<Readonly<globalThis.ExtractPropTypes<{
    name: {
        type: StringConstructor;
        required: true;
    };
    color: {
        type: StringConstructor;
        default: null;
    };
    size: {
        type: (StringConstructor | NumberConstructor)[];
        default: string;
    };
}>>, unknown, unknown, {
    iconStyle(): {
        color: string;
        'font-size': string;
    };
    iconClass(): string;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    size: string | number;
    color: string;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin<any[]>;
export default _default;
