export interface Option {
    id: string | number;
    label: string;
    disabled?: boolean;
    children?: Option[];
}
interface InternalOption extends Option {
    type?: string;
    deep: number;
    hasChildren: boolean;
    children?: InternalOption[];
}
interface PanelOption {
    id?: number;
    parentId?: InternalOption['id'];
    parentDeep?: number;
    menus: InternalOption[];
}
declare const _default: import("vue").DefineComponent<{
    options: {
        type: globalThis.PropType<Option[]>;
        required: true;
    };
    eventTarget: {
        type: (StringConstructor | {
            new (): HTMLElement;
            prototype: HTMLElement;
        })[];
        required: true;
    };
}, unknown, {
    internalOptions: InternalOption[];
    panelOptions: PanelOption[];
    eventTargetEl: HTMLElement | null;
    rootContextmenuId: string;
    isChildrenPanelsClicked: boolean;
    isPanelRightDirection: boolean;
    isPanelsEmptyed: boolean;
}, {
    activeMenuIds(): (string | number | undefined)[];
}, {
    [x: string]: ((option: InternalOption) => boolean) | ((options: InternalOption[], menuId: InternalOption['id']) => InternalOption[] | undefined) | ((contextmenuPanelId: PanelOption['parentId']) => HTMLElement | null | undefined) | (({ event, menu }: {
        event: MouseEvent;
        menu: InternalOption;
    }) => false | undefined) | (({ options, currentMenu }: {
        options: InternalOption[];
        currentMenu?: InternalOption | undefined;
    }) => void) | ((options: Option, deep?: number) => InternalOption) | ((event: MouseEvent) => void) | (({ event, contextmenuId, isRootContextmenu }: {
        event: MouseEvent;
        contextmenuId: string | number;
        isRootContextmenu?: boolean | undefined;
    }) => void) | ((isRemove?: boolean | undefined) => void);
    getRandomIdWithPrefix(): string;
    hasChildren(option: InternalOption): boolean;
    getPanelOptionByMenuId(options: InternalOption[], menuId: InternalOption['id']): InternalOption[] | undefined;
    getParentContextmenuPanelEl(contextmenuPanelId: PanelOption['parentId']): HTMLElement | null | undefined;
    createPanelByHover({ event, menu }: {
        event: MouseEvent;
        menu: InternalOption;
    }): false | undefined;
    createPanelOptions({ options, currentMenu }: {
        options: InternalOption[];
        currentMenu?: InternalOption | undefined;
    }): void;
    createInternalOptionsRecursion(options: Option, deep?: number): InternalOption;
    createInternalOptions(): void;
    showRootContextmenuPanel(event: MouseEvent): void;
    showContextmenuPanel({ event, contextmenuId, isRootContextmenu }: {
        event: MouseEvent;
        contextmenuId: string | number;
        isRootContextmenu?: boolean | undefined;
    }): void;
    emptyContextmenuPanels(): void;
    removeOrEmptyPanels(isRemove?: boolean | undefined): void;
    resetContextmenu(): void;
    addContextmenuPanelToBody({ contextmenuId }: {
        contextmenuId: string | number;
    }): false | undefined;
    addRootContextmenuPanelToBody(): void;
    registerContextmenuEvent(): void;
    removeContextmenuEvent(): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    options: {
        type: globalThis.PropType<Option[]>;
        required: true;
    };
    eventTarget: {
        type: (StringConstructor | {
            new (): HTMLElement;
            prototype: HTMLElement;
        })[];
        required: true;
    };
}>>, {}, {}>;
export default _default;
