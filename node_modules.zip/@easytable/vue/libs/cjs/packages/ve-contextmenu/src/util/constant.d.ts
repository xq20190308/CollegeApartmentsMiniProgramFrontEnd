export declare const PREFIX_CLS = "ve-contextmenu-";
export declare const COMPS_NAME: {
    VE_CONTEXTMENU: string;
};
export declare const EMIT_EVENTS: {
    ON_NODE_CLICK: string;
};
export declare const INIT_DATA: {
    PARENT_DEEP: number;
};
export declare const CONTEXTMENU_NODE_TYPES: {
    SEPARATOR: string;
};
export declare const INSTANCE_METHODS: {
    HIDE_CONTEXTMENU: string;
};
