export declare const PREFIX_CLS = "ve-select-";
export declare const EMIT_EVENTS: {
    SELECT_CHANGE: string;
};
export declare const COMPS_NAME: {
    VE_SELECT: string;
};
