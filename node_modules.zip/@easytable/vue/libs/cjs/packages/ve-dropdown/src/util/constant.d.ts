export declare const PREFIX_CLS = "ve-dropdown-";
export declare const EMIT_EVENTS: {
    FILTER_RESET: string;
    FILTER_CONFIRM: string;
    VISIBLE_CHANGE: string;
    ITEM_SELECT_CHANGE: string;
};
export declare const COMPS_NAME: {
    VE_DROPDOWN: string;
};
