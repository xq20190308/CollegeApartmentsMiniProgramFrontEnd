declare const _default: (props: Record<string, any> & {}) => any;
export default _default;
