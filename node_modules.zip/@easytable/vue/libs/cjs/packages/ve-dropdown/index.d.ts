declare const _default: ((props: Record<string, any> & {}) => any) & import("vue").Plugin<any[]>;
export default _default;
