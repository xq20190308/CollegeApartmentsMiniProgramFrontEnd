declare const _default: import("vue").DefineComponent<{
    modelValue: {
        type: (BooleanConstructor | StringConstructor | NumberConstructor)[];
        default: null;
    };
    label: {
        type: StringConstructor[];
        default: null;
    };
    disabled: BooleanConstructor;
    indeterminate: BooleanConstructor;
    isControlled: {
        type: BooleanConstructor;
        default: boolean;
    };
    isSelected: {
        type: BooleanConstructor;
        default: boolean;
    };
}, () => JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<globalThis.ExtractPropTypes<{
    modelValue: {
        type: (BooleanConstructor | StringConstructor | NumberConstructor)[];
        default: null;
    };
    label: {
        type: StringConstructor[];
        default: null;
    };
    disabled: BooleanConstructor;
    indeterminate: BooleanConstructor;
    isControlled: {
        type: BooleanConstructor;
        default: boolean;
    };
    isSelected: {
        type: BooleanConstructor;
        default: boolean;
    };
}>>, {
    modelValue: string | number | boolean;
    label: string;
    disabled: boolean;
    indeterminate: boolean;
    isControlled: boolean;
    isSelected: boolean;
}, {}>;
export default _default;
